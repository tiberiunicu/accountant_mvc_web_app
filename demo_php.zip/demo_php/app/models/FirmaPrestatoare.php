<?php 

class FirmaPrestatoare{

    private $db;

    public function __construct() {

        $this->db = new Database;

    }

    public function getAll(){
        
        $this->db->query("SELECT * FROM FirmePrestatoareNC");
        
        return $this->db->resultset();
    }
}

?>
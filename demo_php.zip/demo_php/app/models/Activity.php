<?php


class Activity
{

    private $db;

    public function __construct() {

        $this->db = new Database;

    }

    public function insertActivity($data){
        $logDate = date("Y-m-d",strtotime($data['logDate']));

        $sql = "INSERT INTO ActivitateAngajati SET angajatID = '" . $data['angajatID'] . "', tipServiciuID = '". $data['tipServiciuID'] ."', clientID = '" . $data['clientID'] . "',
        logDate = '" . $logDate . "', nrOre = '" . $data['nrOre'] . "', descriere = '" . $data['descriere'] . "'";

        $this->db->query($sql);

        return $this->db->execute();
    }

    public function getActivityByClientServiceAndEmployee($params, $operator = ">="){
        $sql = "SELECT * FROM ActivitateAngajati WHERE clientID = '" . $params['clientID'] . "' ";
        $sql .= "AND tipServiciuID = '" . $params['serviceID'] . "' AND angajatID = '" . $params['employeeID'] . "' ";
        $sql .= "AND logDate $operator '" . $params['dateLimit'] . "'";

        $this->db->query($sql);
        return $this->db->resultset();
    }

    public function updateActivity($params){

        if(!isset($params['activitateAngajatID']['angajatID'])) {
            $sql = "UPDATE ActivitateAngajati SET nrOre = '" . $params['nrOre'] . "', ";
            $sql .= "descriere = '" . $params['descriere'] . "' ";
            $sql .= "WHERE activitateAngajatID = '" . $params['activitateAngajatID'] . "'";
        } else {
            $sql = "INSERT INTO ActivitateAngajati SET angajatID = '" . $params['activitateAngajatID']['angajatID'] . "', ";
            $sql .= "tipServiciuID = '" . $params['activitateAngajatID']['tipServiciuID'] . "', ";
            $sql .= "clientID = '" . $params['activitateAngajatID']['clientID'] . "', ";
            $sql .= "logDate = '" . $params['activitateAngajatID']['logDate'] . "', ";
            $sql .= "nrOre = '" . $params['nrOre'] . "', ";
            $sql .= "descriere = '" . $params['descriere'] . "' ";
        }

        $this->db->query($sql);
        return $this->db->execute();
    }

    public function getEmployeeActivityByDate($angajatID, $date){
        $sql = "SELECT aa.*, c.numeClient, IFNULL(s.numeTipServiciu,'Diverse') AS numeTipServiciu FROM ActivitateAngajati aa ";
        $sql .= "LEFT JOIN Clienti c USING (clientID) LEFT JOIN TipServiciu s USING (tipServiciuID) ";
        $sql .= "WHERE logDate = :date AND angajatID = :angajatID AND nrOre <> 0";

        $this->db->query($sql);
        $this->db->bind(':date', $date);
        $this->db->bind(':angajatID', $angajatID);
        $this->db->execute();

        if($this->db->rowCount() > 0) {
            return $this->db->resultset();
        } else {
            return false;
        }
    }
}
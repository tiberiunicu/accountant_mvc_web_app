<?php 

class Client{

    private $db;

    public function __construct() {

        $this->db = new Database;

    }

       //Find uset By ID 
       public function getByID($id) {

        
        $this->db->query("SELECT * FROM Clienti WHERE clientID = :ID");
        $this->db->bind(':ID', $id);

        $row = $this->db->single();

      return $row;
    }


    public function getAll(){
        
        $this->db->query("SELECT * FROM Clienti");
        
        return $this->db->resultset();
    }

    public function addNew($data){
        $this->db->query('INSERT into Clienti(numeClient,CUI,adminNumeClient,adminEmailClient,adminTelClient,reprezentantNumeClient,reprezentantEmailClient,reprezentantTelClient) 
                    values ('.
                    '\''.$data["newClientName"].'\''. ',' . 
                    '\'' . $data["cuiClient"].'\'' .','. 
                    '\'' . $data["numeAdmin"].'\'' .','. 
                    '\'' . $data["emailAdmin"].'\'' .','. 
                    '\'' . $data["telAdmin"].'\''   .','.
                    '\'' . $data["numeReprezentant"].'\'' .','. 
                    '\'' . $data["emailReprezentant"].'\'' .','. 
                    '\'' . $data["telReprezentant"].'\'' . 
                    ')
                        ');
                        
        $this->db->execute();
        return $this->db->lastInsertId();


    }

    public function updateClientByID($data, $id){

        $sql = "UPDATE Clienti SET numeClient = '" . $data['numeClient'] . "', CUI = '". $data['cuiClient'] ."', adminNumeClient = '" . $data['numeAdmin'] . "',
        adminEmailClient = '" . $data['emailAdmin'] . "', adminTelClient = '" . $data['telAdmin'] . "', reprezentantNumeClient = '" . $data['numeReprezentant'] . "',
        reprezentantEmailClient = '" . $data['emailReprezentant'] . "', reprezentantTelClient = '" . $data['telReprezentant'] . "' WHERE clientID = '" . $id . "'";

        $this->db->query($sql);

        $this->db->execute();

    }

    public function getClientsForUser($userID){

        $sql = "SELECT ctrSrv.*, ctr.*, cli.* FROM ContractServiciu ctrSrv ";
        $sql .= "INNER JOIN Contracte ctr on ctr.contractGUID  = ctrSrv.contractGUID ";
        $sql .= "INNER JOIN Clienti cli on ctr.clientID = cli.clientID ";
        $sql .= "WHERE ctr.isActive = 1 and ";
        $sql .= "CONCAT(',',ctrSrv.angajatIDs,',') like '%,". $userID .",%' ";
        $sql .= "GROUP BY cli.clientID";
        $this->db->query($sql);

        return $this->db->resultset();
    }

}



?>
<?php

class User {

    private $db;

    public function __construct() {

        $this->db = new Database;

    }

    public function getAll(){
        
        $this->db->query("SELECT * FROM Angajati");
        
        return $this->db->resultset();
    }

    //Find uset By ID 
    public function getUserByID($id) {

        
        $this->db->query("SELECT * FROM Angajati WHERE angajatID = :ID");
        $this->db->bind(':ID', $id);

        $row = $this->db->single();

      return $row;
    }

    
    // Find User BY Username
    public function findUserByUsername($username) {

        
        $this->db->query("SELECT * FROM Angajati WHERE email = :username");
        $this->db->bind(':username', $username);

        $row = $this->db->single();

        //Check Rows
        if($this->db->rowCount() > 0){
            return true;
        } else {
            return false;
        }

    }

    // Auth / Authenticate User
    public function login($username, $password) {

        
        $this->db->query("SELECT * FROM Angajati WHERE email = :username");
        $this->db->bind(':username', $username);
        

        $row = $this->db->single();

        $hashed_password = $row->password;

        if(password_verify($password, $hashed_password)){
            return $row;
        } else {
            return false;
        }

    }

}
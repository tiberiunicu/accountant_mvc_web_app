<?php 

class Serviciu{

    private $db;

    public function __construct() {

        $this->db = new Database;

    }

    public function getAll(){
        
        $this->db->query("SELECT * FROM TipServiciu");
        
        return $this->db->resultset();
    }

     public function addNew($data){
         
        $this->db->query('INSERT into TipServiciu(numeTipServiciu) values ('. '\''.$data["newServiceName"].'\')');
        $this->db->execute();
        return $this->db->lastInsertId();

    }

    public function getAllByContractGUID($contractGUID){

        $this->db->query("SELECT * FROM TipServiciu ts JOIN ContractServiciu cs ON (cs.tipServiciuID = ts.tipServiciuID) WHERE cs.contractGUID = '" . $contractGUID . "'");

        return $this->db->resultset();
    }

    public function getAvailableServicesForClientAndEmployee($clientID, $employeeID){
        $sql = "SELECT c.clientID,cs.contractGUID,cs.nrOreServiciu ,srv.tipServiciuID , srv.numeTipServiciu FROM ContractServiciu cs ";
        $sql .= "INNER JOIN TipServiciu srv on srv.tipServiciuID = cs.tipServiciuID ";
        $sql .= "INNER JOIN Contracte c on c.contractGUID = cs.contractGUID ";
        $sql .= "WHERE c.clientID = '" . $clientID . "' AND CONCAT(',',cs.angajatIDs,',') LIKE '%,". $employeeID .",%' AND c.isActive = 1";
        
        $this->db->query($sql);

        return $this->db->resultset();
    }
}

?>
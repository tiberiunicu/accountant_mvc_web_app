<?php 

class Contract{

    private $db;

    public function __construct() {

        $this->db = new Database;

    }

       //Find contract by By ID 
       public function getByID($id) {

        
        $this->db->query("SELECT ctr.*, fp.numeFirmaNC FROM Contracte ctr inner join FirmePrestatoareNC fp on ctr.firmaPrestatoareID = fp.firmaPrestatoareID WHERE contractID = :ID");
        $this->db->bind(':ID', $id);

        $row = $this->db->single();

      return $row;
    }

    public function getMaxContractNumber($firmaPrestatoareID){
        $this->db->query("select MAX(CAST(nrContract as unsigned INT)) as maxNrContract from Contracte where firmaPrestatoareID = '". $firmaPrestatoareID. "' limit 1");
        return $this->db->single();
    }

    public function getAllActiveContracts(){

        $this->db->query(
        "SELECT ctr.*,frmPrest.numeFirmaNC ,cli.numeClient, cli.adminNumeClient ,cli.reprezentantNumeClient ,GROUP_CONCAT(tipSrv.numeTipServiciu SEPARATOR ', ') as servicii 
        FROM Contracte as ctr 
        inner join Clienti as cli on ctr.clientID = cli.ClientID 
        inner join ContractServiciu ctrServ on ctr.contractGUID = ctrServ.contractGUID 
        inner join TipServiciu tipSrv on tipSrv.tipServiciuID = ctrServ.tipServiciuID 
        inner join FirmePrestatoareNC frmPrest on ctr.firmaPrestatoareID = frmPrest.firmaPrestatoareID 
        where ctr.isActive = '1' 
        group by ctr.contractID 
        order by ctr.contractID DESC");
        return $this->db->resultset();
    }

    public function getAllActiveContractsForExport(){
        $this->db->query(
            "SELECT ctr.nrContract as NumarContract, cli.numeClient as NumeClient, cli.adminNumeClient as NumeAdministrator,cli.reprezentantNumeClient as NumeReprezentant, cli.adminTelClient as TelefonAdministrator,frmPrest.numeFirmaNC as FirmaPrestatoare,ctr.tarifRONpeLuna as SUMA, moneda.tipMonedaNume as Moneda ,tipFct.numeFacturare as TipFacturare, GROUP_CONCAT(tipSrv.numeTipServiciu SEPARATOR ', ') as Servicii,ctr.dataIncheiereContract as DataIncheiereContract, ctr.dataExpirareContract as DataFinalizareContract
            FROM Contracte as ctr 
            inner join Clienti as cli on ctr.clientID = cli.ClientID 
            inner join ContractServiciu ctrServ on ctr.contractGUID = ctrServ.contractGUID 
            inner join TipServiciu tipSrv on tipSrv.tipServiciuID = ctrServ.tipServiciuID 
            inner join FirmePrestatoareNC frmPrest on ctr.firmaPrestatoareID = frmPrest.firmaPrestatoareID 
            inner join TipFacturare tipFct on ctr.tipFacturareID = tipFct.tipFacturareID
            inner join TipMoneda moneda on moneda.tipMonedaID = ctr.moneda
            where ctr.isActive = '1' 
            group by ctr.contractID 
            order by ctr.contractID DESC");
        $results = $this->db->resultset();
        return $results;
    }

    public function insertServiceForContract($data){
        $this->db->query('INSERT into ContractServiciu(contractGUID,tipServiciuID,tarifServiciuOra,nrOreServiciu,tarifServiciuTotal,angajatIDs)
        values ('.'\''.$data["contractGUID"] .'\',\'' . $data["tipServiciuID"] .'\',' . $data["tarifServiciuOra"].','.$data["nrOreServiciu"].','
                .$data["tarifServiciuTotal"].',\'' .$data["angajatIDs"].  '\')');

        return $this->db->execute();
    }


    public function addNew($data){
        $today = date("Y-m-d",time());
        $dataFinalizare = date("Y-m-d",strtotime($data['dataFinalizare']));
        $dataIncepere = date("Y-m-d",strtotime($data['dataIncepere']));
            $this->db->query('INSERT into Contracte(contractGUID,nrContract,clientID,dataIncheiereContract,dataExpirareContract,tipFacturareID,moneda,tarifRONpeLuna,firmaPrestatoareID)
        values ('.
            '\''.$data['contractGUID'] . '\''.','.
            '\''.$data['contractNumber'] . '\''.','.
            '\''.$data['clientID'] . '\''.','.
            '\''.$dataIncepere. '\''.','.
            '\''.$dataFinalizare. '\''.','.
            '\''.$data['tipFacturareID']. '\''.','.
            '\''.$data['tipMonedaID']. '\''.','.
            '\''.$data['sumaLunara']. '\''.','.
            '\''.$data['firmaPrestatoareID'] . '\''.
            ')
        ');
        
        return $this->db->execute();
        
    }

    public function deleteServicesBycontractGUID($contractGUID){
        $this->db->query("DELETE FROM ContractServiciu WHERE contractGUID = '" . $contractGUID . "'");

        return $this->db->execute();
    }

    public function updateContractByID($data, $id){
        $dataIncepere = date("Y-m-d",strtotime($data['dataIncepere']));
        $dataFinalizare = date("Y-m-d",strtotime($data['dataFinalizare']));

        $sql = "UPDATE Contracte SET nrContract = '" . $data['contractNumber'] . "',dataIncheiereContract = '". $dataIncepere . "' , clientID = '". $data['clientID'] ."', dataExpirareContract = '" . $dataFinalizare . "',
        tipFacturareID = '" . $data['tipFacturareID'] . "', tarifRONpeLuna = '" . $data['sumaLunara'] . "', firmaPrestatoareID = '" .$data['firmaPrestatoareID'] . "'  WHERE contractID = '" . $id . "'";

        $this->db->query($sql);

        return $this->db->execute();
    }

public function deleteContractByID($id){
    $this->db->query("UPDATE Contracte set isActive = '0' WHERE contractID = :ID");
    $this->db->bind(':ID', $id);

    $row = $this->db->execute();
    echo $row;
    if ($row > 0){
        return true;
    }
    return false;
}

    public function ApplyFilters($data){
        $firmaPrestatoare = ($data['firmaPrestatoareFilter'] != '') ? ' = '.$data['firmaPrestatoareFilter'] : ' > 0' ;
        $strRpl = [
            '{numeClientFilter}' => $data['numeClientFilter'],
            '{cuiClient}' => $data['cuiFilter'],
            '{numeAdminFilter}' => $data['numeAdministratorFilter'],
            '{firmaPrestatoare}' => $firmaPrestatoare
        ];

        $queryString =
            "SELECT ctr.* ,cli.numeClient ,cli.adminNumeClient ,cli.reprezentantNumeClient ,GROUP_CONCAT(tipSrv.numeTipServiciu SEPARATOR ', ') as servicii 
    FROM Contracte as ctr 
    inner join Clienti as cli on ctr.clientID = cli.ClientID 
    inner join ContractServiciu ctrServ on ctr.contractGUID = ctrServ.contractGUID
    inner join TipServiciu tipSrv on tipSrv.tipServiciuID = ctrServ.tipServiciuID
    
    
    where ctr.isActive = '1' 
    AND cli.numeClient like '%{numeClientFilter}%' 
    AND cli.CUI like '%{cuiClient}%' 
    and (cli.adminNumeClient like '%{numeAdminFilter}%' or cli.reprezentantNumeClient like '%{numeAdminFilter}%') 
    and ctr.firmaPrestatoareID {firmaPrestatoare}
    
    group by ctr.contractID
    order by ctr.contractID DESC";
        $this->db->query(strtr($queryString, $strRpl));

        return $this->db->resultset();
    }

}



?>
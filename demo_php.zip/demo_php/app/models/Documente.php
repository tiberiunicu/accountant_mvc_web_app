<?php

class Documente
{

    private $db;

    public function __construct()
    {

        $this->db = new Database;
    }

    public function getByID($id)
    {
        $this->db->query("SELECT * FROM Documente WHERE documentGUID = :ID");
        $this->db->bind(':ID', $id);

        $row = $this->db->single();
        return $row;
    }

    public function file_details($data)
    {
        $this->db->query('insert into Documente(documentGUID,contractGUID,documentName) values('.'\''.$data["documentGUID"] .'\',\'' . $data["contractGUID"] .'\',' . $data["documentName"].'\')');
    }
}

<?php 

class TipFacturare{

    private $db;

    public function __construct() {

        $this->db = new Database;

    }

    public function getAll(){
        
        $this->db->query("SELECT * FROM TipFacturare");
        
        return $this->db->resultset();
    }

    public function getByID($id){
        $this->db->query("SELECT * FROM TipFacturare WHERE tipFacturareID = :ID");
        $this->db->bind(':ID', $id);

        $row = $this->db->single();
        return $row;
    }
}

?>
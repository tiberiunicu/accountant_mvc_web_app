<?php

class Menu extends Controller {

    public function __construct(){
        $this->db = new Database;
        $this->userModel = $this->model('User');
    }

    // Load Menu
    public function index() {

        // If logged in, redirect to posts
        if(!isset($_SESSION['user_id'])){
            redirect('auth');
        }

        $userEntity = $this->userModel->getUserByID($_SESSION['user_id']);

        //Set Data
        $data = [
            'title' => 'N&C Consulting Management',
            'numeAngajat' => $userEntity->numeAngajat,
            'email'=>$userEntity->email,
            'accessToFacturi'=>$userEntity->accessToFacturi,
            'accessToContracte'=>$userEntity->accessToContracte,
            'accessToRaportare'=>$userEntity->accessToRaportare,
            'accessToAngajati'=>$userEntity->accessToAngajati
        ];

        // Load homepage/index view
        $this->view('menu', $data);

    }

    

    public function page() {

        echo 'test_page';

    }

}
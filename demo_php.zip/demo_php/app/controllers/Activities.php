<?php 

class Activities extends Controller{


    public function __construct(){

        $this->db = new Database;
        $this->contractModel = $this->model('Contract');
        $this->serviceModel = $this->model('Serviciu');
        $this->clientModel = $this->model('Client');
        // $this->tipFacturareModel = $this->model('TipFacturare');
        $this->angajatModel = $this->model('User');
        $this->activityModel = $this->model('Activity');
        $this->firmaPrestatoareModel = $this->model('FirmaPrestatoare');

    }


    public function index() {

        // If logged in, redirect to posts
        if(!isset($_SESSION['user_id'])){
            redirect('auth');
        }

        $user = $this->angajatModel->getUserByID($_SESSION['user_id']);

        $data['user'] = $user;
        $data['pageName'] = 'Adauga activitate';
        $data['clients'] = $this->clientModel->getClientsForUser($_SESSION['user_id']);
        $data['worklog'] = [];

        date_default_timezone_set("Europe/Bucharest");
        if(isset($_POST['dataSelectata'])) {
            $dataSelectata = new DateTime($_POST['dataSelectata']);
        } else {
            $dataSelectata = new DateTime();
        }

        if($dataSelectata->format('w') == 6) {
            $dataSelectata->modify('-1 day');
        }

        if($dataSelectata->format('w') == 0) {
            $dataSelectata->modify('-2 day');
        }

        setlocale(LC_TIME, array('ro.utf-8', 'ro_RO.UTF-8', 'ro_RO.utf-8', 'ro', 'ro_RO', 'ro_RO.ISO8859-2'));

        $data['dataSelectata'] = [
            'data' => $dataSelectata->format('Y-m-d'),
            'afisare' => strftime('%d %B %Y', $dataSelectata->getTimestamp())
        ];

        $data['worklog']['services'] = $this->serviceModel->getAll();

        $diverse = new stdClass();
        $diverse->tipServiciuID = 0;
        $diverse->numeTipServiciu = 'Diverse';
        $data['worklog']['services'][] = $diverse;



        foreach($data['clients'] as $client) {

            $data['worklog']['clients'][$client->numeClient] = [
                'clientID' => $client->clientID
            ];

            $services = $this->serviceModel->getAvailableServicesForClientAndEmployee($client->clientID, $_SESSION['user_id']);
            $diverse = new stdClass();
            $diverse->clientID = $client->clientID;
            $diverse->tipServiciuID = 0;
            $diverse->numeTipServiciu = 'Diverse';
            $services[] = $diverse;

            $clientServicesIDs = [];

            foreach($services as $service) {
                $clientServicesIDs[] = $service->tipServiciuID;
            }
            $clientServicesIDs = array_unique($clientServicesIDs);

            foreach($data['worklog']['services'] as $service) {

                    if( in_array($service->tipServiciuID, $clientServicesIDs)) {
                        $aParams = [
                            'clientID' => $client->clientID,
                            'serviceID' => $service->tipServiciuID,
                            'employeeID' => $_SESSION['user_id'],
                            'dateLimit' => $dataSelectata->format('Y-m-d')
                        ];

                        // extract existing employee activities by client and services
                        $activity = $this->activityModel->getActivityByClientServiceAndEmployee($aParams,'=');
                        $loggedActivity = [];
                        foreach ($activity as $log) {
                            $loggedActivity[$log->tipServiciuID] = [
                                'nrOre' => $log->nrOre,
                                'descriere' => $log->descriere,
                                'activitateAngajatID' => $log->activitateAngajatID
                            ];
                        }

                        $data['worklog']['clients'][$client->numeClient]['services'][$service->numeTipServiciu] = [
                            'serviceID' => $service->tipServiciuID,
                        ];


                        if (array_key_exists($service->tipServiciuID, $loggedActivity)) {
                            $data['worklog']['clients'][$client->numeClient]['services'][$service->numeTipServiciu]['activity'] = [
                                'nrOre' => $log->nrOre,
                                'descriere' => $log->descriere,
                                'activitateAngajatID' => $log->activitateAngajatID
                            ];
                        } else {
                            $data['worklog']['clients'][$client->numeClient]['services'][$service->numeTipServiciu]['activity'] = [
                                'nrOre' => 0,
                                'descriere' => ''
                            ];
                        }
                    } else {
                        $data['worklog']['clients'][$client->numeClient]['services'][$service->numeTipServiciu] = [
                            'serviceID' => $service->tipServiciuID,
                        ];
                    }
            }
        }

        // Load activity view
        $this->view('activity/angajat', $data);

    }

    public function admin() {
        // If logged in, redirect to posts
        if(!isset($_SESSION['user_id'])){
            redirect('auth');
        }

        $user = $this->angajatModel->getUserByID($_SESSION['user_id']);

        $data['user'] = $user;
        $data['pageName'] = 'Manageriaza activitate';
        $data['selectAngajati'] = $this->angajatModel->getAll();
        $data['angajati'] = [];

        date_default_timezone_set("Europe/Bucharest");

        if(isset($_POST['angajatID'])) {
            $time = strtotime($_POST['dataSelectata']);
        } else {
            $time = time();
        }

        $dataSelectata = date('Y-m-d', $time);
        $firstWeekDay = strtotime("this week", $time);

        setlocale(LC_TIME, array('ro.utf-8', 'ro_RO.UTF-8', 'ro_RO.utf-8', 'ro', 'ro_RO', 'ro_RO.ISO8859-2'));

        foreach($data['selectAngajati'] as $angajat) {

            if(isset($_POST['angajatID']) && $angajat->angajatID !== $_POST['angajatID']) {
                continue;
            }

            $data['angajati'][$angajat->numeAngajat] = [
                'angajatID' => $angajat->angajatID
            ];

            for ($i = 0; $i < 7; $i++) {
                $time = $firstWeekDay + $i * 60 * 60 * 24;
                $data['angajati'][$angajat->numeAngajat]['dates'][] = [
                    'data' => date('Y-m-d', $time),
                    'week-day' => rtrim(ucwords(strftime('%a', $time)), '.'),
                    'month-day' => rtrim(ucwords(strftime('%#d/%m', $time)), '.'),
                    'dataSelectata' => date('Y-m-d', $time) === $dataSelectata ? true : false,
                    'weekend' => in_array(strftime('%w', $time), [0, 6]) ? true : false
                ];
            }

            $clients = $this->clientModel->getClientsForUser($angajat->angajatID);

            foreach ($clients as $client) {

                $data['angajati'][$angajat->numeAngajat]['clients'][$client->numeClient] = [
                    'clientID' => $client->clientID
                ];

                $services = $this->serviceModel->getAvailableServicesForClientAndEmployee($client->clientID, $angajat->angajatID);
                $diverse = new stdClass();
                $diverse->clientID = $client->clientID;
                $diverse->tipServiciuID = 0;
                $diverse->numeTipServiciu = 'Diverse';
                $services[] = $diverse;

                foreach ($services as $service) {

                    $aParams = [
                        'clientID' => $client->clientID,
                        'serviceID' => $service->tipServiciuID,
                        'employeeID' => $angajat->angajatID,
                        'dateLimit' => $data['angajati'][$angajat->numeAngajat]['dates'][0]['data']
                    ];

                    // extract existing employee activities by client and services
                    $activity = $this->activityModel->getActivityByClientServiceAndEmployee($aParams);
                    $loggedActivity = [];
                    foreach ($activity as $log) {
                        $loggedActivity[$log->logDate] = [
                            'nrOre' => $log->nrOre,
                            'descriere' => $log->descriere,
                            'activitateAngajatID' => $log->activitateAngajatID
                        ];
                    }

                    $data['angajati'][$angajat->numeAngajat]['clients'][$client->numeClient]['services'][$service->numeTipServiciu] = [
                        'serviceID' => $service->tipServiciuID,
                    ];

                    // mapping dates with existing employee activities
                    foreach ($data['angajati'][$angajat->numeAngajat]['dates'] as $date) {

                        if (array_key_exists($date['data'], $loggedActivity)) {
                            $data['angajati'][$angajat->numeAngajat]['clients'][$client->numeClient]['services'][$service->numeTipServiciu]['activity'][$date['data']] = [
                                'nrOre' => $loggedActivity[$date['data']]['nrOre'],
                                'descriere' => $loggedActivity[$date['data']]['descriere'],
                                'activitateAngajatID' => $loggedActivity[$date['data']]['activitateAngajatID'],
                                'dataSelectata' => $date['dataSelectata'],
                                'weekend' => $date['weekend']
                            ];
                        } else {
                            $data['angajati'][$angajat->numeAngajat]['clients'][$client->numeClient]['services'][$service->numeTipServiciu]['activity'][$date['data']] = [
                                'nrOre' => 0,
                                'descriere' => '',
                                'dataSelectata' => $date['dataSelectata'],
                                'weekend' => $date['weekend']
                            ];
                        }
                    }
                }
            }
        }

        // Load activity view
        $this->view('activity/admin', $data);
    }

    public function show() {

        date_default_timezone_set("Europe/Bucharest");

        $today = new DateTime();

        if($today->format('w') == 6) {
            $today->modify('-1 day');
        }

        if($today->format('w') == 0) {
            $today->modify('-2 day');
        }

        setlocale(LC_TIME, array('ro.utf-8', 'ro_RO.UTF-8', 'ro_RO.utf-8', 'ro', 'ro_RO', 'ro_RO.ISO8859-2'));

        $data['today'] = [
            'data' => $today->format('Y-m-d'),
            'afisare' => strftime('%d %B %Y', $today->getTimestamp())
        ];

        $data['todayWorklog'] = $this->activityModel->getEmployeeActivityByDate($_SESSION['user_id'], $data['today']['data']);

        $this->view('activity/show', $data);
    }

    public function getAvailableServicesForClientIDAndEmployee(){

        if (isset($_POST['servicesForClient'])){
            $clientID = $_POST['servicesForClient'];
            $servicesForClient = $this->serviceModel->getAvailableServicesForClientAndEmployee($clientID,$_SESSION['user_id']);
            echo json_encode($servicesForClient);
        }

    }
//    Salvare Activitate Start
    public function saveActivity(){

        if (isset($_POST['angajatID'])){
            $angajatID = $_POST['angajatID'];
            $clientID = $_POST['clientID'];
            $tipServiciuID = $_POST['tipServiciuID'];
            $logDate = $_POST['logDate'];
            $nrOre = $_POST['nrOre'];
            $descriere = $_POST['descriere'];
        }

        $dataActivity = [
            "angajatID"=>$angajatID,
            "clientID"=>$clientID,
            "tipServiciuID"=>$tipServiciuID,
            "logDate"=>$logDate,
            "nrOre"=>$nrOre,
            "descriere"=>$descriere
        ];

        echo $this->activityModel->insertActivity($dataActivity);
    }
//    Salvare Activitate End

    public function updateActivity() {

        if(isset($_POST['name'])){
            $activitateAngajatID = $_POST['pk'];
            $nrOre = $_POST['value']['nrOre'];
            $descriere = $_POST['value']['descriere'];
        }

        $dataActivity = [
            "activitateAngajatID"=>$activitateAngajatID,
            "nrOre"=>$nrOre,
            "descriere"=>$descriere
        ];

        echo $this->activityModel->updateActivity($dataActivity);
    }
}


?>
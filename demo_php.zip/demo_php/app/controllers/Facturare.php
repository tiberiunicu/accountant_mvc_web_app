<?php 
class Facturare extends Controller{

    public function __construct(){

        $this->db = new Database;
        $this->contractModel = $this->model('Contract');
        // $this->serviceModel = $this->model('Serviciu');
        $this->clientModel = $this->model('Client');
        $this->tipFacturareModel = $this->model('TipFacturare');
        $this->userModel = $this->model('User');
        $this->firmaPrestatoareModel = $this->model('FirmaPrestatoare');

    }

        // Load Menu
        public function index() {

            // If logged in, redirect to posts
            if(!isset($_SESSION['user_id'])){
                redirect('auth');
            }

            $facturareEntities = $this->tipFacturareModel->getAll();
            $contractEntities  = $this->contractModel->getAllActiveContracts();
            $contractEntitiesToShow = array();

            foreach ($contractEntities as $contract){
                $contractTipFacturareID = $contract->tipFacturareID;
                $diff = date_diff(new DateTime("now"),new DateTime($contract->dataIncheiereContract));
                $months = $diff->format('%m');
                switch($contractTipFacturareID){
                    case "1":
                        $contract->sumaDeFacturat = $contract->tarifRONpeLuna;
                        array_push($contractEntitiesToShow,$contract);
                    break;
                    case"2":
                        if ($months%3 == 0){
                            $contract->sumaDeFacturat = doubleval($contract->tarifRONpeLuna) * 3;
                            array_push($contractEntitiesToShow,$contract);
                        }
                    break;
                    case"3":
                        if ($months%6 == 0){
                            $contract->sumaDeFacturat = doubleval($contract->tarifRONpeLuna) * 6;
                            array_push($contractEntitiesToShow,$contract);
                        }
                    break;
                    case"4":
                        if ($months == 0){
                            $contract->sumaDeFacturat = doubleval($contract->tarifRONpeLuna) * 12;
                            array_push($contractEntitiesToShow,$contract);
                        }
                    break;
                }
                foreach ($facturareEntities as $tipFacturare){
                    if ($contract->tipFacturareID == $tipFacturare->tipFacturareID){
                        $contract->numeTipFacturare = $tipFacturare->numeFacturare;
                    }
                }
            }
            
            // var_dump($contractEntities);
            // die();
            $userEntity = $this->userModel->getUserByID($_SESSION['user_id']);
            $data['pageName']  = 'Facturare';
            //Set Data
            $data = [
                'title' => 'N&C Consulting Management',
                'numeAngajat' => $userEntity->numeAngajat,
                'email'=>$userEntity->email,
                'contracts'=>$contractEntitiesToShow
            ];
            $data['pageName']  = 'Facturi de emis in luna curenta';
            // Load homepage/index view
            $this->view('facturare', $data);
    
        }



}







?>
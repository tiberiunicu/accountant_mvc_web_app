<?php

class Documente extends Controller
{

    public function __construct()
    {
        $this->db = new Database;
        $this->userModel = $this->model('User');
        $this->model = $this->model('Documente');
    }


    // function file_upload()
    // {
    //     if (isset($_POST['submit'])) {
    //         $output_dir = "public/uploads"; //Path for file upload
    //         $fileCount = count($_FILES["image"]['name']);
    //         $RandomNum = time();
    //         // $ImageName = str_replace(' ', '-', strtolower($_FILES['image']['name'][$i]));
    //         // $ImageType = $_FILES['image']['type'][$i]; //"image/png", image/jpeg etc.
    //         // $ImageExt = substr($ImageName, strrpos($ImageName, '.'));
    //         $ImageExt = str_replace('.', '', $ImageExt);
    //         $ImageName = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
    //         $NewImageName = $ImageName . '-' . $RandomNum . '.' . $ImageExt;
    //         $ret[$NewImageName] = $output_dir . $NewImageName;
    //         move_uploaded_file($_FILES["image"]["tmp_name"][$i], $output_dir . "/" . $NewImageName);
    //         $data = array(
    //             'image' => $NewImageName
    //         );
    //         $this->model->file_details($data);
    //         echo "Image Uploaded Successfully";
    //     }
    // }










    // Load Menu
    // public function index() {

    //     // If logged in, redirect to posts
    //     if(!isset($_SESSION['user_id'])){
    //         redirect('auth');
    //     }

    //     $userEntity = $this->userModel->getUserByID($_SESSION['user_id']);

    //     //Set Data
    //     $data = [
    //         'title' => 'N&C Consulting Management',
    //         'numeAngajat' => $userEntity->numeAngajat,
    //         'email'=>$userEntity->email,
    //         'accessToFacturi'=>$userEntity->accessToFacturi,
    //         'accessToContracte'=>$userEntity->accessToContracte,
    //         'accessToRaportare'=>$userEntity->accessToRaportare,
    //         'accessToAngajati'=>$userEntity->accessToAngajati
    //     ];

    //     // Load homepage/index view
    //     $this->view('menu', $data);

    // }



    // public function page() {

    //     echo 'test_page';

    // }



}

<?php

class Auth extends Controller {

    public function __construct() {
        $this->userModel = $this->model('User');
    }

    public function index() {

        // Check if logged in
        if($this->isLoggedIn()){
            redirect('menu');
        }

        // Check if POST
        if($_SERVER['REQUEST_METHOD'] == 'POST') {

            // Sanitize POST data
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            // Init data
            $data = [
                'username' => trim($_POST['username']),
                'password' => trim($_POST['password']),
                'username_err' => '',
                'password_err' => '',
            ];

            // Username required
            if (empty($data['username'])) {
                $data['username_err'] = 'Utilizatorul este obligatoriu';
            } elseif (!$this->userModel->findUserByUsername($data['username'])) {
                $data['username_err'] = 'Acest utilizator nu exista.';
            }

            // Password required
            if (empty($data['password'])) {
                $data['password_err'] = 'Parola este obligatorie';
            }

            // Make sure errors are empty
            if (empty($data['username_err']) && empty($data['password_err'])) {

                // Check and set logged in user
                $loggedInUser = $this->userModel->login($data['username'], $data['password']);

                if ($loggedInUser){
                    // User Authenticated!
                    $this->createUserSession($loggedInUser);
                } else {
                    $data['password_err'] = 'Parola pentru acest utilizator este incorecta';

                    $this->view('login', $data);
                }
            } else {
                // Load the view with errors
                $this->view('login', $data);
            }

        } else {
            // Init data
            $data = [
                'username' => '',
                'password' => '',
                'username_err' => '',
                'password_err' => '',
            ];
            $data['pageName'] = 'Meniu principal';
            // Load view
            $this->view('login', $data);
        }

    }

    public function logout() {

        unset($_SESSION['user_id']);
        unset($_SESSION['username']);
        session_destroy();
        redirect('auth');

    }

    // Create Session With User Info
    public function createUserSession($user){

        $_SESSION['user_id'] = $user->angajatID;
        $_SESSION['username'] = $user->email;
        redirect('menu');

    }

    // Check Logged In
    public function isLoggedIn(){

        if(isset($_SESSION['user_id'])){
            return true;
        } else {
            return false;
        }

    }

}
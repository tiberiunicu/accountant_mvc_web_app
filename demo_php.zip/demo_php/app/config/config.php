<?php

// DB Params
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "quickmen_ncconsulting");

// App Root
define('APPROOT', dirname(dirname(__FILE__)));
// URL Root
define('URLROOT', 'http://ncconsulting.local');
// Site Name
define('SITENAME', 'N&C Group');
  
<?php 
$db = new Database();
$this->db->query("SELECT numeAngajat FROM Angajati WHERE angajatID = " . $_SESSION['user_id']);
$user = $this->db->single();
$pageName = isset($data['pageName']) ? $data['pageName'] : '';
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-3 pr-0">
    <div class="col-12 row pr-0">
        <a class="navbar-brand" href="<?php echo URLROOT; ?>">
        
            <h4 class="display-5"><span onclick="window.history.back();"><i class="fas fa-arrow-left fa-lg"></i> </span><?php echo " &nbsp; ". SITENAME; ?></h4>
        </a>
        <div class="col-7 mx-auto text-center mt-2" id="navBarPageName">
        <h4 class="display-5"><?php echo $pageName; ?></h4>
        </div>
        <div class="dropdown ml-auto">
            <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <?php echo 'Bun venit, ' .$user->numeAngajat; ?>
            </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                <a class="dropdown-item" href="<?php echo URLROOT; ?>/auth/logout"><i class="fa fa-sign-out"
                        aria-hidden="true"></i> Logout</a>
            </div>
        </div>
    </div>
</nav>
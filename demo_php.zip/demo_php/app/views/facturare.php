<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/nav.php'; ?>
<div id="facturareBody">
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Numar Contract</th>
                <th scope="col">Nume Client</th>
                <th scope="col">Valoare factura<br> <span style="font-size:10px;">(Tarif ron/luna X Nr De luni)</span>
                </th>
                <th scope="col">Tip facturare</th>
                <th scope="col">Data factura</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($data['contracts'] as $contract): ?>
            <tr>
                <th scope="row"><?php echo $contract->nrContract; ?></th>
                <td><?php echo $contract->numeClient; ?></td>
                <td><?php echo $contract->sumaDeFacturat . " RON"; ?></td>
                <td><?php echo $contract->numeTipFacturare; ?></td>
                <td><?php echo $contract->dataIncheiereContract; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php require APPROOT . '/views/inc/footer.php'; ?>
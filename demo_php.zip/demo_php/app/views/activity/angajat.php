<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/nav.php'; ?>


<div id="activityBody" class="col-12 row mx-0 px-0">
    <div id="addWorkLogSection" class="col-12">
        <div class="card">
            <div class="card-body">
                <form id="activityForm" action="<?php echo URLROOT . '/Activities'; ?>" method="post">
                    <div id="workLogRow" class="row workLog-item">
                        <div class="form-group col-12 col-md-7">
                            <label for="dataSelectata">Data</label>
                            <input type="text" name="dataSelectata" class="form-control date validate-input" autocomplete="off" data-provide="datepicker"
                                   id="dataSelectata" placeholder="Data">
                        </div>

                        <div class="form-group col-12 col-md-2 my-auto mx-auto text-center">
                            <button type="submit" class="mt-3 btn btn-primary">Selecteaza Data </button>
                        </div>
                        <div class="form-group col-12 col-md-3 my-auto mx-auto text-center">
                            <div onclick="showTodayActivity('<?php echo URLROOT; ?>')" class="mt-3 btn btn-info">Vizualizeaza activitatea de azi </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="WorkLogTableSection" class="col-12 activitateAngajat">
        <div id="table-scroll" class="table-scroll">
            <div class="table-wrap">
                <table class="main-table">
                    <thead class="bg-info">
                    <tr>
                        <th class="fixed-side" scope="col">
                            <?php echo $data['dataSelectata']['afisare']; ?>
                        </th>
                        <?php foreach($data['worklog']['services'] as $service): ?>
                        <th scope="col"><?php echo $service->numeTipServiciu; ?></th>
                        <?php endforeach; ?>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($data['worklog']['clients'] as $clientName => $client): ?>
                    <tr>
                        <th class="fixed-side client"><span class="client-text"><?php echo $clientName; ?></span></th>

                            <?php foreach($client['services'] as $serviceName => $service): ?>
                                <td class="">
                                    <?php if(!isset($service['activity'])): ?>
                                        <a class="disabled"></a>
                                    <?php elseif(isset($service['activity']['activitateAngajatID'])): ?>
                                        <a href="#" class="editable" data-type="address"
                                           data-name="<?php  echo 'log-' .  $service['activity']['activitateAngajatID']; ?>"
                                           data-placement="right"
                                           data-value="{nrOre: '<?php echo $service['activity']['nrOre']; ?>',descriere: '<?php  echo $service['activity']['descriere']; ?>'}"
                                           data-title="<?php echo $data['dataSelectata']['data']; ?>"
                                           data-pk="<?php echo $service['activity']['activitateAngajatID']; ?>"><?php echo $service['activity']['nrOre']; ?>
                                        </a>
                                    <?php else: ?>
                                        <?php
                                            $jsonAddParams = "{";
                                            $jsonAddParams .= "angajatID: '" . $data['user']->angajatID . "',";
                                            $jsonAddParams .= "tipServiciuID: '" . $service['serviceID'] . "',";
                                            $jsonAddParams .= "clientID: '" . $client['clientID'] . "',";
                                            $jsonAddParams .= "logDate: '" .  $data['dataSelectata']['data'] . "',";
                                            $jsonAddParams .= "}" ;
                                        ?>
                                        <a href="#" class="editable" data-type="address"
                                           data-placement="right"
                                           data-value="{nrOre: '<?php echo $service['activity']['nrOre']; ?>',descriere: '<?php  echo $service['activity']['descriere']; ?>'}"
                                           data-title="<?php echo $data['dataSelectata']['data']; ?>"
                                           data-pk="<?php echo $jsonAddParams; ?>"><?php echo $service['activity']['nrOre']; ?>
                                        </a>
                                    <?php endif ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>

                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="todayActivity" tabindex="-1" role="dialog" aria-labelledby="todayActivityLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">

        </div>
    </div>
</div>

<script type="text/javascript">
$(document).ready(function() {
    $('.date').datepicker({
        format: 'yyyy-mm-dd',
        daysOfWeekDisabled: [0, 6],
        weekStart: 1,
        startDate: startDate(),
        endDate: 'today'
    });
    $('.date').datepicker("setDate", suggestedDate());

    $(".main-table").clone(true).appendTo('.table-scroll').addClass('clone');

    $.fn.editable.defaults.mode = 'popup';
    // $.fn.editable.defaults.placement = 'top';
    $('.editable').editable({
        url: '/Activities/updateActivity',
        type: 'text',
        pk: 1
    });

});
</script>
<?php require APPROOT . '/views/inc/footer.php'; ?>

<div class="modal-header p-4">
    <h5 class="col-12 modal-title text-center">Activitate inregistrata in ultima zi lucratoare (<?php echo $data['today']['afisare'] ;?>)</h5>
</div>
<div class="modal-body">

    <div class="table-responsive-sm">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>#</th>
                <th>Client</th>
                <th>Serviciu</th>
                <th>Nr Ore</th>
                <th>Descriere</th>
            </tr>
            </thead>
            <tbody>
            <?php
                if($data['todayWorklog']):
                $servicuNr = 1;
                foreach($data['todayWorklog'] as $log):
            ?>
            <tr>
                <td><?php echo $servicuNr; ?></td>
                <td><?php echo $log->numeClient; ?></td>
                <td><?php echo $log->numeTipServiciu; ?></td>
                <td><?php echo $log->nrOre; ?></td>
                <td><?php echo $log->descriere; ?></td>
            </tr>
            <?php
                $servicuNr++;
                endforeach;
                else:
            ?>
            <tr>
                <td class="text-center" colspan="5">Nu exista activitate</td>
            </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="modal-footer bg-white">
    <button type="button" class="btn btn-secondary mx-auto" data-dismiss="modal">INCHIDE</button>
</div>

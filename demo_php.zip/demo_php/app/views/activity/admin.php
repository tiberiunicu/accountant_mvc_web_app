<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/nav.php'; ?>


<div id="activityBody" class="col-12 row mx-0 px-0">
    <div id="addWorkLogSection" class="col-12">
        <div class="card">
            <div class="card-body">
                <form id="activityForm" action="<?php echo URLROOT . '/Activities/admin'; ?>" method="post">
                    <div id="workLogActions" class="row workLog-item">
                        <div class="form-group col-12 col-md-5">
                            <label for="selectAngajat">Angajat :</label>
                            <select id="selectAngajat" name="angajatID" class="selectpicker form-control customDropdown px-0 validate-input"
                                    data-live-search="true" title="Selecteaza Angajat">
                                <?php foreach ($data['selectAngajati'] as $angajat): ?>
                                    <option value="<?php echo $angajat->angajatID?>">
                                        <?php echo $angajat->numeAngajat; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group col-12 col-md-5">
                            <label for="dataSelectata">Data</label>
                            <input type="text" name="dataSelectata" class="form-control date validate-input" autocomplete="off" data-provide="datepicker"
                                   id="dataSelectata" placeholder="Data">
                        </div>
                        <div class="form-group col-12 col-md-2 my-auto mx-auto text-center">
                            <button type="submit" class="mt-3 btn btn-primary">Aplica modificari </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $tableCounter = 1; ?>
    <?php foreach($data['angajati'] as $numeAngajat => $angajat): ?>
    <div id="WorkLogTableSection" class="col-12">
        <div id="table-scroll-<?php echo $tableCounter; ?>" class="table-scroll">
            <div class="table-wrap">
                <table class="main-table">
                    <thead class="bg-info">
                    <tr>
                        <th colspan="8" class="angajat"><?php echo strtoupper($numeAngajat); ?></th>
                    </tr>
                    <tr>
                        <th class="fixed-side" scope="col">Servicii</th>
                        <?php foreach($angajat['dates'] as $date): ?>
                            <th class="<?php echo $date['dataSelectata'] ? 'today' : ''; ?>" scope="col">
                                <div><?php echo $date['week-day']; ?></div>
                                <div><?php echo $date['month-day']; ?></div>
                            </th>
                        <?php endforeach; ?>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($angajat['clients'] as $clientName => $client): ?>
                        <tr class="client">
                            <td class="fixed-side" colspan="8"><span class="client-text"><?php echo $clientName; ?></span></td>
                        </tr>
                        <?php foreach($client['services'] as $serviceName => $service): ?>
                            <tr>
                                <th class="fixed-side"><?php echo $serviceName; ?></th>

                                <?php foreach($service['activity'] as $date => $log): ?>

                                    <td class="<?php echo $log['dataSelectata'] ? 'today' : ($log['weekend'] ? 'weekend' : ''); ?>">
                                        <?php if($log['weekend']): ?>
                                        <?php elseif(isset($log['activitateAngajatID'])): ?>
                                            <a href="#" class="editable" data-type="address"
                                               data-name="<?php  echo 'log-' .  $log['activitateAngajatID']; ?>"
                                               data-placement="right"
                                               data-value="{nrOre: '<?php  echo $log['nrOre']; ?>',descriere: '<?php  echo $log['descriere']; ?>'}"
                                               data-title="<?php echo $date; ?>"
                                               data-pk="<?php echo $log['activitateAngajatID']; ?>"><?php echo $log['nrOre']; ?>
                                            </a>
                                        <?php else: ?>
                                            <a class="disabled"><?php echo $log['nrOre']; ?></a>
                                        <?php endif ?>
                                    </td>

                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
    <?php $tableCounter++; ?>
    <?php endforeach; ?>
</div>
<script type="text/javascript">
$(document).ready(function() {

    $("#activityForm").on('submit', function() {
        if(!validateActivity()){
            return false
        }
    });

    $('.date').datepicker({
        format: 'yyyy-mm-dd',
        daysOfWeekDisabled: [0, 6],
        weekStart: 1,
        endDate: 'today'
    });

    $('.date').datepicker("setDate",  suggestedDate());

    var tableCounter = 1;
    $('.main-table').each(function (key, value){
        $(this).clone(true).appendTo('#table-scroll-' + tableCounter).addClass('clone');
        tableCounter++;
    });
    //$(".main-table").clone(true).appendTo('.table-scroll').addClass('clone');

    $.fn.editable.defaults.mode = 'popup';
    // $.fn.editable.defaults.placement = 'top';
    $('.editable').editable({
        url: '/Activities/updateActivity',
        type: 'text',
        pk: 1,
    });

});
</script>
<?php require APPROOT . '/views/inc/footer.php'; ?>
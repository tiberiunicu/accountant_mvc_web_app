<div class="modal-header p-4">
    <div class="float-left my-auto">
        <h5><?php echo $data['numeClient']; ?></h5>
        <ul class="list list-unstyled mb-0 text-left">
            <li class="text-cui"><strong>(CUI <?php echo $data['CUI']; ?>)</strong></li>
        </ul>
    </div>
    <div class="float-right">
        <h4 class="contract-color">Contract nr. <?php echo $data['numarContract'];  ?></h4>
        <h5 class="contract-color">Firma Prestatoare:. <?php echo $data['firmaPrestatoare'];  ?></h5>
        <ul class="list list-unstyled mb-0">
            <li><strong>Data Contractare:</strong> <span class="font-weight-semibold"><?php echo $data['dataIncheiere'];  ?></span></li>
            <li><strong>Data Expirare:</strong> <span class="font-weight-semibold"><?php echo $data['dataExpirare'];  ?></span></li>
        </ul>
    </div>
</div>
<div class="modal-body">
    <div class="row mb-4">
        <?php if (!empty($data['reprezentantNumeClient']) || !empty($data['reprezentantEmailClient']) || !empty($data['reprezentantTelClient'])) : ?>
            <div class="col-sm-6 text-center">
            <?php else : ?>
                <div class="col-sm-12 text-center">
                <?php endif; ?>
                <h6 class="mb-2">Informatii Administrator:</h6>
                <h5 class="text-dark mb-1"><?php echo $data['adminNumeClient']; ?></h5>
                <div>Email: <a href="mailto:<?php echo $data['adminEmailClient']; ?>"><?php echo $data['adminEmailClient']; ?></a></div>
                <div>Telefon: <a href="tel:<?php echo $data['adminTelClient']; ?>"><?php echo $data['adminTelClient']; ?></a></div>
                </div>
                <?php if (!empty($data['reprezentantNumeClient']) || !empty($data['reprezentantEmailClient']) || !empty($data['reprezentantTelClient'])) : ?>
                    <div class="col-sm-6 text-center">
                        <h6 class="mb-2">Informatii Reprezentant:</h6>
                        <?php if (!empty($data['reprezentantNumeClient'])) : ?>
                            <h5 class="text-dark mb-1"><?php echo $data['reprezentantNumeClient']; ?></h5>
                        <?php endif; ?>
                        <?php if (!empty($data['reprezentantEmailClient'])) : ?>
                            <div>Email: <a href="mailto:<?php echo $data['reprezentantEmailClient']; ?>"><?php echo $data['reprezentantEmailClient']; ?></a></div>
                        <?php endif; ?>
                        <?php if (!empty($data['reprezentantTelClient'])) : ?>
                            <div>Telefon: <a href="tel:<?php echo $data['reprezentantTelClient']; ?>"><?php echo $data['reprezentantTelClient']; ?></a></div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="table-responsive-sm">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Serviciu</th>
                            <th>Tarif Ora</th>
                            <th>Nr Ore</th>
                            <th>Angajati</th>
                            <th>Tarif Serviciu Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $servicuNr = 1;
                        foreach ($data['servicii'] as $key => $serviciu) :
                        ?>
                            <tr>
                                <td><?php echo $servicuNr; ?></td>
                                <td><?php echo $serviciu['numeTipServiciu']; ?></td>
                                <td><?php echo $serviciu['tarifServiciuOra']; ?></td>
                                <td><?php echo $serviciu['nrOreServiciu']; ?></td>
                                <td><?php echo $serviciu['angajati']; ?></td>
                                <td><?php echo $serviciu['tarifServiciuTotal']; ?></td>
                            </tr>
                        <?php
                            $servicuNr++;
                        endforeach;
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="row">
                <div class="col-sm-6">
                </div>
                <div class="col-sm-6 ml-auto">
                    <table class="table table-clear">
                        <tbody>
                            <tr>
                                <td><strong class="text-dark">Tip facturare:</strong></td>
                                <td><?php echo $data['tipFacturare']; ?></td>
                            </tr>
                            <tr>
                                <td><strong class="text-dark">Tarif pe Luna:</strong></td>
                                <td><strong class="text-dark"><?php echo $data['tarifRonPeLuna']; ?></strong></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
    </div>
    <div class="modal-footer bg-white">
        <button type="button" class="btn btn-secondary mx-auto" data-dismiss="modal">INCHIDE</button>
    </div>
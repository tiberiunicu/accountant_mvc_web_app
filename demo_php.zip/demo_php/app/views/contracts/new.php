<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/nav.php'; ?>


<div class="hidden" id="hiddenListOfInitialClientCUIs">
    <!-- put in LIST for clientside validation -->
    <?php foreach ($data['clients'] as $client) : ?>
        <li class="initialClientCUI"><?php echo preg_replace("/[^0-9]/", "", $client->CUI); ?></li>
    <?php endforeach; ?>
</div>

<!-- <div class="progress col-12 px-0" id="progressbar">
    <div class="progress-bar bg-info nav-link active p-0" id="progressBar-section1" role="progressbar"
        style="width: 33%" aria-valuenow="33" aria-valuemin="0" aria-valuemax="100" href="#contract-section1">Numar
        contract si selectie client</div>
    <div class="progress-bar nav-link p-0" id="progressBar-section2" role="progressbar" style="width: 33%"
        aria-valuenow="33" aria-valuemin="0" aria-valuemax="100" href="#contract-section2">Estimare numar ore si
        selectie servicii</div>
    <div class="progress-bar bg-success nav-link p-0" id="progressBar-section3" role="progressbar" style="width: 34%"
        aria-valuenow="34" aria-valuemin="0" aria-valuemax="100" href="#contract-section3">Adaugare referenti si
        ultimele detalii </div>
</div> -->

<div id="addContractBody" class="col-9 mx-auto my-5 needs-validation" data-spy="scroll" data-target="#progressbar" data-offset="0">
    <div class="contract-section1 col-12 mt-3" id="contract-section1">
        <fieldset>
            <legend>
                <h3> Contract nou </h3>
            </legend>
            <!-- <form method="post" action="" enctype="multipart/form-data">
                <input type="file" name="image[]" id="uploadFilesInput">
                <button class="btn btn-warning" id="butsave" onclick="uploadDocuments('<?php echo URLROOT; ?>')">Incarca<span class="glyphicon glyphicon-send"></span></button>
            </form> -->
            <div class="form-row">
                <div class="form-group col-3">
                    <label for="firmaPrestatoareSelect">Firma prestatoare :</label>
                    <select id="firmaPrestatoareSelect" class="selectpicker form-control customDropdown px-0 validate-input" data-live-search="true" title="Selecteaza firma prestatoare din grup" onchange="setThisFirmaPrestatoare('<?php echo URLROOT ?>',this)">
                        <?php foreach ($data['firmaPrestatoare'] as $firmaPrestatoare) : ?>
                            <option data-firmaprestatoareid="<?php echo $firmaPrestatoare->firmaPrestatoareID ?>">
                                <?php echo $firmaPrestatoare->numeFirmaNC; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group col-3">
                    <label for="numarContractInput">Numar contract :</label>
                    <input type="text" class="form-control validate-input" value="" id="numarContractInput" placeholder="Introduceti numarul contractului">
                </div>
                <div class="form-group col-4">
                    <label for="sumaLunaraInput">Suma lunara :</label>
                    <input type="number" min="0" class="form-control validate-input" id="sumaLunaraInput" placeholder="Introduceti suma lunara stabilita in contract">
                </div>
                <div class="form-group col-2 facturareSelectParent">
                    <label for="monedaSelect">Moneda :</label>
                    <select id="monedaSelect" class="selectpicker form-control customDropdown px-0 validate-input" data-live-search="true" title="Moneda">
                        <?php foreach ($data['moneda'] as $tipMoneda) : ?>
                            <option data-monedaid="<?php echo $tipMoneda->tipMonedaID; ?> ">
                                <?php echo $tipMoneda->tipMonedaNume; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-4 facturareSelectParent">
                    <label for="facturareSelect">Tip Facturare :</label>
                    <select id="facturareSelect" class="selectpicker form-control customDropdown px-0 validate-input" data-live-search="true" title="Selecteaza tipul facturarii">
                        <?php foreach ($data['tipFacturare'] as $tipFacturare) : ?>
                            <option data-facturareid="<?php echo $tipFacturare->tipFacturareID; ?> ">
                                <?php echo $tipFacturare->numeFacturare; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group col-4">
                    <label for="dataIncepereContractInput">Data incepere contract :</label>
                    <input type="text" class="form-control date validate-input" data-provide="datepicker" id="dataIncepereContractInput" placeholder="Data incepere contract">
                </div>

                <div class="form-group col-3">
                    <label for="dataFinalizareContractInput">Data finalizare contract :</label>
                    <input type="text" class="form-control date " data-provide="datepicker" id="dataFinalizareContractInput" placeholder="Data finalizare contract">
                </div>
                <div class="form-group col-1">
                    <label for="contractPerioadaNedeterminata">Nedeterminat</label>
                    <input type="checkbox" id="contractPerioadaNedeterminata">
                </div>

            </div>
            <div class="form-row">

            </div>

        </fieldset>
        <fieldset id="client">
            <legend>
                <h3> Client </h3>
            </legend>
            <div class="form-group">
                <label for="clientNameValue">Nume Client :</label>
                <input type="text" class="form-control validate-input" id="clientNameValue" placeholder="Cauta client dupa nume" onkeyup="searchClientByName(this)">
                <div id="clientList" class="hidden mx-0 px-0">
                    <ul class="list-group text-center">
                        <?php foreach ($data['clients'] as $client) : ?>
                            <li class="list-group-item client-list-element" onclick='setClientOnSession(<?php echo json_encode($client); ?>)'>
                                <?php echo $client->numeClient; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-6">
                    <label for="cuiClientInput">CUI Client :</label>
                    <input type="text" class="form-control validate-input" id="cuiClientInput" placeholder="CUI Client" onkeyup="validateUniqueCUI(this)">
                </div>

                <div class="form-group col-6">
                    <label for="numeAdministratorInput">Nume Administrator :</label>
                    <input type="text" class="form-control validate-input" id="numeAdministratorInput" placeholder="Numele administrtorului / persoana de contact">
                </div>
            </div>
            <div class="form-row">

                <div class="form-group col-6">
                    <label for="emailAdministratorInput">Email Administrator:</label>
                    <input type="text" class="form-control validate-input" id="emailAdministratorInput" placeholder="Email administrator / persoana de contact" onkeyup="validateEmailAddress(this)">
                </div>

                <div class="form-group col-6 row mx-auto">
                    <label for="telefonAdministratorInput" class="col-12">Telefon Administrator:</label>
                    <select id="prefixAdministratorSelect" class="selectpicker col-4 form-control customDropdown validate-input" data-live-search="true" title="Prefixul tarii">
                        <?php foreach ($data['phoneNumbersPrefixes'] as $key => $value) : ?>
                            <option data-countryID="<?php echo $key; ?> ">
                                <?php echo $value; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" class="form-control validate-input col-8" id="telefonAdministratorInput" placeholder="Telefon administrator / persoana de contact" onkeyup="validatePhoneNumberMaxLength(this)">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-4">
                    <label for="numeReprezentantInput">Nume Reprezentant:</label>
                    <input type="text" class="form-control" id="numeReprezentantInput" placeholder="Nume reprezentant (poate fi lasat gol)">
                </div>
                <div class="form-group col-3">
                    <label for="emailReprezentantInput">Email Reprezentant:</label>
                    <input type="text" class="form-control" id="emailReprezentantInput" placeholder="Email reprezentant (poate fi lasat gol)" onkeyup="validateEmailAddress(this)">
                </div>

                <div class="form-group col-5 row mx-auto">
                    <label for="telefonReprezentantInput" class="col-12">Telefon Reprezentant:</label>
                    <select id="prefixReprezentantSelect" class="selectpicker col-4 form-control customDropdown " data-live-search="true" title="Prefixul tarii">
                        <?php foreach ($data['phoneNumbersPrefixes'] as $key => $value) : ?>
                            <option data-countryID="<?php echo $key; ?> ">
                                <?php echo $value; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" class="form-control col-8" id="telefonReprezentantInput" placeholder="Telefon reprezentant (poate fi lasat gol)" onkeyup="validatePhoneNumberMaxLength(this)">
                </div>
            </div>
        </fieldset>
    </div>

    <div class="contract-section2 col-12 mx-0 mt-3" id="contract-section2">
        <fieldset class="service-item mb-3">
            <p id="serviceHiddenId" class="hidden"></p>
            <p id="angajatiHiddenIds" class="hidden"></p>
            <p id="firmaPrestatoareHiddenId" class="hidden"></p>
            <legend>
                <h3 class="float-left"> Serviciul <span class="serviceCounter">1</span></h3>
                <div class="float-left btn btn-danger ml-3" onclick="deleteService(this)">
                    <i class="far fa-trash-alt"></i>
                </div>
                <div class="float-right btn btn-primary" id="addServiceButton" onclick="duplicateServiceItem(this)">
                    <i class="fas fa-plus"></i>&nbsp; Adauga serviciu
                </div>
            </legend>
            <div class="form-row">
                <div class="form-group col-12 serviceSelectParent">
                    <label for="serviceSelect">Nume serviciu :</label>
                    <select id="serviceSelect" class="selectpicker form-control customDropdown px-0 validate-input" data-live-search="true" title="Selecteaza serviciu" onchange="setThisService(this)">
                        <?php foreach ($data['services'] as $service) : ?>
                            <option data-serviceid="<?php echo $service->tipServiciuID; ?> ">
                                <?php echo $service->numeTipServiciu; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group col-6 hidden" id="newServiceName">
                    <label for="newServiceNameInput">Nume serviciu nou :</label>
                    <input type="text" class="form-control" id="newServiceNameInput" placeholder="Nume serviciu nou">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-6">
                    <label for="angajatiSelect">Angajat / Referent :</label>
                    <select id="angajatiSelect" class="selectpicker form-control customDropdown px-0 validate-input" multiple data-live-search="true" title="Selecteaza angajat" onchange="setAngajatForThisService(this)">
                        <?php foreach ($data['angajati'] as $angajat) : ?>
                            <option data-angajatid="<?php echo $angajat->angajatID ?>"><?php echo $angajat->numeAngajat; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group col-6">
                    <label for="tarifServiciuTotalInput">Pretul estimat pentru serviciu :</label>
                    <input type="number" min="0" class="form-control validate-input" id="tarifServiciuTotalInput" placeholder="Pretul estimat pentru serviciu" onkeyup="checkServiceCorrectnessByServiciuTotalInput(this)">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-6">
                    <label for="numarOreInput">Numar ore estimate :</label>
                    <input type="number" min="0" class="form-control validate-input" id="numarOreInput" placeholder="Numar ore estimate">
                </div>

                <div class="form-group col-6">
                    <label for="tarifOraInput">Tarif / ora :</label>
                    <input type="number" value="60" min="0" class="form-control validate-input" id="tarifOraInput" onkeyup="checkServiceCorrectnessByServiciuTotalInput(this)" placeholder="Tarif/ora">
                </div>
            </div>
        </fieldset>
    </div>

    <div class="col-4 mx-auto text-center m-4" id="addContractButton" onclick="saveContract('<?php echo URLROOT; ?>')">
        <div class="btn btn-success py-3 px-4"><i class="fas fa-save"></i>&nbsp; Salveaza contract </div>
    </div>
</div>

<div class="modal fade" id="saveContractModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" data-keyboard="false" data-backdrop="static" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Salvare contract</h5>
                <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button> -->
            </div>
            <div class="modal-body">
                <div class="d-flex justify-content-center">
                    <div class="spinner-border" role="status">
                        <span class="sr-only">Se salveaza contractul...</span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <!-- <button type="button" id="doneButton" data-dismiss="modal" class="btn btn-success" >Gata</button> -->
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        clearPHPContractGUID('<?php echo URLROOT; ?>');
        $('.date').datepicker({
            format: 'yyyy-mm-dd',
            daysOfWeekDisabled: [0, 6],
            weekStart: '1'
        });
        $('#dataIncepereContractInput').datepicker("setDate", new Date());

        $('#contractPerioadaNedeterminata').on("change",function(event){
            if ($('#contractPerioadaNedeterminata').prop("checked")){
               $('#dataFinalizareContractInput').attr("disabled",true); 
            }else{
                $('#dataFinalizareContractInput').attr("disabled",false); 
            }
        })
    });
</script>

<?php require APPROOT . '/views/inc/footer.php'; ?>
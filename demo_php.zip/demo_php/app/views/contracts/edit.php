<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/nav.php'; ?>


<div class="hidden" id="hiddenListOfInitialClientCUIs">
    <!-- put in LIST for clientside validation -->
    <?php
            foreach($data['clients'] as $client):
            if($data['contract']['CUI'] != $client->CUI):
        ?>
    <li class="initialClientCUI"><?php echo preg_replace("/[^0-9]/","",$client->CUI); ?></li>
    <?php
            endif;
            endforeach;
        ?>
</div>

<div id="addContractBody" class="col-9 mx-auto my-5 needs-validation" data-spy="scroll" data-target="#progressbar"
    data-offset="0">
    <div class="contract-section1 col-12 mt-3" id="contract-section1">
        <fieldset>
            <legend>
                <h3>Contract</h3>
            </legend>
            <div class="form-row">
                <div class="form-group col-3">
                    <label for="firmaPrestatoareSelect">Firma prestatoare :</label>
                    <select id="firmaPrestatoareSelect"
                        class="selectpicker form-control customDropdown px-0 validate-input" data-live-search="true"
                        title="Selecteaza firma prestatoare din grup"
                        onchange="setThisFirmaPrestatoare('<?php echo URLROOT ?>',this)">
                        <?php foreach ($data['firmaPrestatoare'] as $firmaPrestatoare): ?>
                        <option data-firmaprestatoareid="<?php echo $firmaPrestatoare->firmaPrestatoareID ?>"
                            <?php if($data['contract']['firmaPrestatoareID'] == $firmaPrestatoare->firmaPrestatoareID) { echo 'selected'; }?>>
                            <?php echo $firmaPrestatoare->numeFirmaNC; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group col-3">
                    <label for="numarContractInput">Numar contract :</label>
                    <input type="text" class="form-control validate-input" id="numarContractInput"
                        placeholder="Introduceti numarul contractului"
                        value="<?php echo $data['contract']['numarContract'];?>">
                </div>
                <div class="form-group col-6">
                    <label for="sumaLunaraInput">Suma lunara :</label>
                    <input type="number" min="0" class="form-control validate-input" id="sumaLunaraInput"
                        placeholder="Introduceti suma lunara stabilita in contract"
                        value="<?php echo $data['contract']['tarifRonPeLuna'];?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-4 facturareSelectParent">
                    <label for="facturareSelect">Tip Facturare :</label>
                    <select id="facturareSelect" class="selectpicker form-control customDropdown px-0 validate-input"
                        data-live-search="true" title="Selecteaza tipul facturarii">
                        <?php foreach ($data['tipFacturare'] as $tipFacturare): ?>
                        <option data-facturareid="<?php echo $tipFacturare->tipFacturareID;?> "
                            <?php if($data['contract']['tipFacturare'] == $tipFacturare->tipFacturareID) { echo 'selected'; }?>>
                            <?php echo $tipFacturare->numeFacturare; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group col-4">
                    <label for="dataIncepereContractInput">Data incepere contract :</label>
                    <input type="text" class="form-control date validate-input" data-provide="datepicker"
                        id="dataIncepereContractInput" placeholder="Data incepere contract" 
                        value="<?php echo $data['contract']['dataIncepere'];?>"> 
                </div>
                <div class="form-group col-4">
                    <label for="dataFinalizareContractInput">Data finalizare contract :</label>
                    <input type="text" class="form-control date validate-input" data-provide="datepicker"
                        id="dataFinalizareContractInput" placeholder="Data finalizare contract"
                        value="<?php echo $data['contract']['dataExpirare'];?>">
                </div>
            </div>
        </fieldset>
        <fieldset id="client">
            <legend>
                <h3> Client </h3>
            </legend>
            <div class="form-group">
                <label for="clientNameValue">Nume Client :</label>
                <input type="text" class="form-control validate-input" id="clientNameValue" disabled
                    placeholder="Cauta client dupa nume" value="<?php echo $data['contract']['numeClient'];?>">
                <div id="clientList" class="hidden mx-0 px-0">
                    <ul class="list-group text-center">
                        <?php foreach($data['clients'] as $client): ?>
                        <li class="list-group-item client-list-element">
                            <?php echo $client->numeClient; ?></li>
                        <?php endforeach;?>
                    </ul>
                </div>
            </div>
            <div class="form-row">
                <p id="invalidCUIMessage" class="hidden col-5 text-center"> Exista un client cu acest CUI </p>
                <div class="form-group col-6">
                    <label for="cuiClientInput">CUI Client :</label>
                    <input type="text" class="form-control validate-input" disabled id="cuiClientInput" placeholder="CUI Client"
                        onkeyup="validateUniqueCUI(this)" value="<?php echo $data['contract']['CUI'];?>">
                </div>

                <div class="form-group col-6">
                    <label for="numeAdministratorInput">Nume Administrator :</label>
                    <input type="text" class="form-control validate-input"  disabled id="numeAdministratorInput"
                        placeholder="Numele administrtorului / persoana de contact"
                        value="<?php echo $data['contract']['adminNumeClient'];?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-6">
                    <label for="emailAdministratorInput">Email Administrator:</label>
                    <input type="text" class="form-control validate-input" disabled id="emailAdministratorInput"
                        placeholder="Email administrator / persoana de contact"
                        value="<?php echo $data['contract']['adminEmailClient'];?> "
                        onkeyup="validateEmailAddress(this)">
                </div>

                <div class="form-group col-6 row mx-auto">
                    <label for="telefonAdministratorInput" class="col-12">Telefon Administrator:</label>
                    <select id="prefixAdministratorSelect"
                        class="selectpicker col-4 form-control customDropdown validate-input" disabled data-live-search="true"
                        title="Prefixul tarii">
                        <?php foreach ($data['phoneNumbersPrefixes'] as $key=>$value): ?>
                        <option data-countryID="<?php echo $key;?>" <?php echo ($key ==  json_decode($data['contract']['adminTelClient'])->prefix) ? 'selected' : ''  ?>>
                            <?php echo $value; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" class="form-control validate-input col-8"  disabled id="telefonAdministratorInput"
                        placeholder="Telefon administrator / persoana de contact"
                        onkeyup="validatePhoneNumberMaxLength(this)" value="<?php echo  json_decode($data['contract']['adminTelClient'])->phone; ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-4">
                    <label for="numeReprezentantInput">Nume Reprezentant:</label>
                    <input type="text" class="form-control"  disabled id="numeReprezentantInput"
                        placeholder="Nume reprezentant (poate fi lasat gol)"
                        value="<?php echo $data['contract']['reprezentantNumeClient'];?>">
                </div>
                <div class="form-group col-3">
                    <label for="emailReprezentantInput">Email Reprezentant:</label>
                    <input type="text" class="form-control"  disabled id="emailReprezentantInput"
                        placeholder="Email reprezentant (poate fi lasat gol)"
                        value="<?php echo $data['contract']['reprezentantEmailClient'];?>"
                        onkeyup="validateEmailAddress(this)">
                </div>

                <div class="form-group col-5 row mx-auto">
                    <label for="telefonReprezentantInput" class="col-12">Telefon Reprezentant:</label>
                    <select id="prefixReprezentantSelect" disabled class="selectpicker col-4 form-control customDropdown "
                        data-live-search="true" title="Prefixul tarii">
                        <?php foreach ($data['phoneNumbersPrefixes'] as $key=>$value): ?>
                        <option data-countryID="<?php echo $key;?> " <?php echo ($key ==  json_decode($data['contract']['reprezentantTelClient'])->prefix) ? 'selected' : ''  ?>  >
                            <?php echo $value; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" class="form-control col-8" disabled id="telefonReprezentantInput" value="<?php echo is_object($data['contract']['reprezentantTelClient']) ?  json_decode($data['contract']['reprezentantTelClient'])->phone : ''; ?>"
                        placeholder="Telefon reprezentant (poate fi lasat gol)" onkeyup="validatePhoneNumberMaxLength(this)">
                </div>
            </div>
        </fieldset>
    </div>

    <div class="contract-section2 col-12 mx-0 mt-3" id="contract-section2">
        <?php foreach($data['contract']['servicii'] as $key => $serviciu): ?>
        <fieldset class="service-item mb-3">
            <p id="serviceHiddenId" class="hidden"></p>
            <p id="angajatiHiddenIds" class="hidden"></p>
            <p id="firmaPrestatoareHiddenId" class="hidden"></p>
            <legend>
                <h3 class="float-left"> Serviciul <span class="serviceCounter"><?php echo $key + 1; ?></span></h3>
                <div class="float-left btn btn-danger ml-3" onclick="deleteService(this)">
                    <i class="far fa-trash-alt"></i>
                </div>
                <div class="float-right btn btn-primary" id="addServiceButton" onclick="duplicateServiceItem(this)">
                    <i class="fas fa-plus"></i>&nbsp; Adauga serviciu
                </div>
            </legend>
            <div class="form-row">
                <div class="form-group col-12 serviceSelectParent">
                    <label for="serviceSelect">Nume serviciu :</label>
                    <select id="serviceSelect" class="selectpicker form-control customDropdown px-0 validate-input"
                        data-live-search="true" title="Selecteaza serviciu" onchange="setThisService(this)">
                        <?php foreach ($data['services'] as $service): ?>
                        <option data-serviceid="<?php echo $service->tipServiciuID;?> "
                            <?php if($serviciu['tipServiciuID'] == $service->tipServiciuID) { echo 'selected'; }?>>
                            <?php echo $service->numeTipServiciu; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group col-6 hidden" id="newServiceName">
                    <label for="newServiceNameInput">Nume serviciu nou :</label>
                    <input type="text" class="form-control" id="newServiceNameInput" placeholder="Nume serviciu nou">
                </div>
            </div>
            <div class="form-row"">
                <div class=" form-group col-6">
                <label for="angajatiSelect">Angajat / Referent :</label>
                <select id="angajatiSelect" class="selectpicker form-control customDropdown px-0 validate-input"
                    multiple data-live-search="true" title="Selecteaza angajat"
                    onchange="setAngajatForThisService(this)">
                    <?php foreach ($data['angajati'] as $angajat): ?>
                    <option data-angajatid="<?php echo $angajat->angajatID?>"
                        <?php if(in_array($angajat->angajatID, $serviciu['angajati'])) { echo 'selected'; }?>>
                        <?php echo $angajat->numeAngajat; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group col-6">
                <label for="tarifServiciuTotalInput">Pretul estimat pentru serviciu :</label>
                <input type="number" min="0" class="form-control validate-input" id="tarifServiciuTotalInput"
                    placeholder="Pretul estimat pentru serviciu" value="<?php echo $serviciu['tarifServiciuTotal'];?>"  onkeyup="checkServiceCorrectnessByServiciuTotalInput(this)">
            </div>
    </div>

    <div class="form-row">
        <div class="form-group col-6">
            <label for="numarOreInput">Numar ore estimate :</label>
            <input type="number" min="0" class="form-control validate-input" id="numarOreInput"
                placeholder="Numar ore estimate" value="<?php echo $serviciu['nrOreServiciu'];?>">
        </div>

        <div class="form-group col-6">
            <label for="tarifOraInput">Tarif / ora :</label>
            <input type="number" min="0" class="form-control validate-input" id="tarifOraInput" placeholder="Tarif/ora" onkeyup="checkServiceCorrectnessByServiciuTotalInput(this)"
                value="<?php echo $serviciu['tarifServiciuOra'];?>">
        </div>
    </div>
    </fieldset>
    <?php endforeach; ?>
</div>

<div class="col-4 mx-auto text-center m-4" id="updateContractButton"
    onclick="updateContract('<?php echo URLROOT; ?>','<?php echo $data['contract']['contractID']; ?>')">
    <div class="btn btn-success py-3 px-4"><i class="fas fa-save"></i>&nbsp; Editeaza contract </div>
</div>
</div>

<div class="modal fade" id="updateContractModal" tabindex="-1" role="dialog" aria-labelledby="updateContractModalLabel"
    data-keyboard="false" data-backdrop="static" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="updateContractModalLabel">Modificare contract</h5>
                <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button> -->
            </div>
            <div class="modal-body">
                <div class="d-flex justify-content-center">
                    <div class="spinner-border" role="status">
                        <span class="sr-only">Se modifica contractul...</span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <!-- <button type="button" id="doneButton" data-dismiss="modal" class="btn btn-success" >Gata</button> -->
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
$(document).ready(function() {
    $('.date').datepicker({
        format: 'yyyy-mm-dd',
        // startDate: 'today',
        daysOfWeekDisabled: [0, 6],
        weekStart: '1'
    });
});
</script>

<?php require APPROOT . '/views/inc/footer.php'; ?>
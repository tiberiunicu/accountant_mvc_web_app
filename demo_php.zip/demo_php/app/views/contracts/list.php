<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/nav.php'; ?>

<div class="hidden" id="hiddenFieldUserAccessToContracts" data-hasAccessToContracts="<?php echo $data['user']->accessToContracte; ?>"></div>
<div class="hidden" id="hiddenURLROOT" data-URLROOT="<?php echo URLROOT; ?>"></div>
<div id="mySidebar" class="sidebar col-12 row mx-0 px-0">
    <div id="filterContent" class="col-12 mx-0">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <br><br>
        <div class="form-group col-12 px-1">
            <label for="numeClientSearchInput">Nume Client (Companie) :</label>
            <input type="text" class="form-control" id="numeClientSearchInput" placeholder="Cauta nume client">
        </div>
        <div class="form-group col-12 px-1">
            <label for="numeAdministratorSearchInput">Nume administrator :</label>
            <input type="text" class="form-control" id="numeAdministratorSearchInput" placeholder="Cauta nume administrator">
        </div>
        <div class="form-group col-12 px-1">
            <label for="cuiSearchInput">CUI:</label>
            <input type="text" class="form-control" id="cuiSearchInput" placeholder="Cauta CUI Client">
        </div>
        <div class="form-group col-12 px-1">
            <label for="firmaPrestatoareSearchSelect">Firma prestatoare :</label>
            <select id="firmaPrestatoareSearchSelect" class="selectpicker form-control customDropdown px-0 validate-input" data-live-search="true" title="Selecteaza firma prestatoare din grup">
                <?php foreach ($data['firmaPrestatoare'] as $firmaPrestatoare) : ?>
                    <option data-firmaprestatoareid="<?php echo $firmaPrestatoare->firmaPrestatoareID ?>">
                        <?php echo $firmaPrestatoare->numeFirmaNC; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-12 row mx-0 px-0" id="filterButtons">
            <div class="col-6">
                <div class="btn btn-danger" onclick="resetFilters()">
                    <i class="fas fa-undo"></i> Reset</div>
            </div>
            <div class="col-6">
                <div class="btn btn-primary" onclick="applyFilters('<?php echo URLROOT; ?>')">
                    <i class="fas fa-search"></i> Cauta</div>
            </div>
        </div>
    </div>
</div>

<div id="contractListBody" class="col-12 row px-0 mr-0">
    <div class="col-12 row pr-0  mb-2">
        <div class="col-1" id="openSidebarIcon" onclick="openNav()">
            <i class="fas fa-sliders-h"></i> Deschide filtre
        </div>
        <div class="col-6 text-center ml-auto mr-0 pr-0">
            <!-- <h1> Contracte active</h1> -->
            <!-- <button class="openbtn" onclick="openNav()">&#9776; Open Sidebar</button> -->
            <div class="col-8 ml-auto mr-0" ><input type="text" class="form-control validate-input " placeholder="Căutare universală" onkeyup="cautareUniversala(this)"></div>
        </div>

        <div class="col-6 text-right pr-0">
            
            <div class="btn btn-warning" id="contracteCareExpira" onclick="contracteCareExpira()"><i class="fa fa-calendar"></i> Contracte care expira</div>
            <div class="btn btn-warning hidden" id="afiseazaToate" onclick="afiseazaToate()"><i class="fa fa-refresh"></i> Afiseaza toate</div>
            <div class="btn btn-secondary" onclick="exportContracts('<?php echo URLROOT; ?>')"><i class="fa fa-file-excel-o"></i> Exporta in EXCELL</div>
            <?php if ($data['user']->accessToContracte) : ?>
                <div class="btn btn-success" onclick="goToAddContractsPage('<?php echo URLROOT; ?>')"><i class="fas fa-plus"></i> Adauga contract</div>
            <?php else : ?>
                <div class="btn btn-success opacity-0" id="btnPlaceholder"> Button placeholder for users with no contracts
                    rights </div>
            <?php endif; ?>
        </div>

    </div>
    <div class="col-12 overflow-auto table-wrapper">
        <table class="table table-striped">
            <thead>
                <tr class="table-primary">
                    <th scope="col"></th>
                    <th scope="col">Nr. Contract </th>
                    <th scope="col">Nume Client</th>
                    <th scope="col">Administrator</th>
                    <th scope="col">Firma prestatoare</th>
                    <th scope="col">Data Incepere</th>
                    <th scope="col">Data Finalizare</th>

                    <th scope="col servicii-header">Servicii</th>
                    <!-- <th scope="col">Tarif lunar</th> -->
                    <th class="center" scope="col">Actiuni</th>
                </tr>
            </thead>
            <tbody id="contractsListTable">
                <?php foreach ($data['contracts'] as $contract) :  ?>
                    <?php
                    $class = "";
                    if (strtotime($contract->dataExpirareContract) < strtotime("now")) {
                        $class = "expired";
                    } else if (strtotime($contract->dataExpirareContract) < strtotime("+1 months")) {
                        $class = "expiring";
                    }
                    ?>
                    <tr data-contractID="<?php echo $contract->contractID; ?>" class="contract-item <?php echo $class ?>">
                        <td scope="center">
                            <?php if ($data['user']->accessToContracte) : ?>
                                <span class="text-danger" title="Sterge contract" onclick="showDeleteContractModal('<?php echo URLROOT; ?>','<?php echo $contract->contractID; ?>','<?php echo $contract->nrContract; ?>', '<?php echo $contract->numeClient; ?>')">
                                    <i class="fas fa-trash-alt fa-lg"></i></span>
                            <?php endif; ?>
                        </td>
                        <td scope="row"><?php echo $contract->nrContract; ?></td>
                        <td class="left"><?php echo $contract->numeClient; ?></td>
                        <td class="left"><?php echo $contract->adminNumeClient; ?></td>
                        <td class="left"><?php echo $contract->numeFirmaNC; ?></td>
                        <td class="left"><?php echo $contract->dataIncheiereContract; ?></td>
                        <td class="left <?php echo strtotime($contract->dataExpirareContract) < strtotime("now") ? "btn-danger" : "" ?>  
                                    <?php echo strtotime($contract->dataExpirareContract) < strtotime("+1 months") ? "btn-warning" : "" ?>">
                            <!-- will expire this MONTH -->
                            <?php echo $contract->dataExpirareContract; ?>
                        </td>

                        <td class="left servicii-value"><?php echo $contract->servicii; ?></td>
                        <td class="center action-buttons">
                            <span class="text-info" title="Vizualizare contract" onclick="showViewContractModal('<?php echo URLROOT; ?>','<?php echo $contract->contractID; ?>')">
                                <i class="fas fa-eye fa-lg"></i></span>
                            <?php if ($data['user']->accessToContracte) : ?>
                                <span class="text-primary" title="Modifica contract" onclick="editContract('<?php echo URLROOT; ?>','<?php echo $contract->contractID; ?>')">
                                    <i class="fas fa-edit fa-lg"></i></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach;  ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="deleteContract" tabindex="-1" role="dialog" aria-labelledby="deleteContractLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteContractLabel">Stergere contract</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                ...
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">ANULEAZA</button>
                <button type="button" id="acceptButton" class="btn btn-danger">DA</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="viewContract" tabindex="-1" role="dialog" aria-labelledby="viewContractLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">

        </div>
    </div>
</div>
<?php require APPROOT . '/views/inc/footer.php'; ?>
<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/nav.php'; ?>
<?php if(isset($_SESSION['user_id'])) : ?>
<div id="menu-page-body" class="col-12">
    <div class="module-buttons-parent col-12 col-md-7 mx-auto mt-3 row text-center">
        <div class="col-10 mx-auto row px-0">
            <div class=" col-11 col-md-5 col-md-5-custom mx-auto module-button bg-primary row text-center" onclick="goToContracts('<?php echo URLROOT; ?>')">
                <i class="fas fa-file-contract ml-auto mr-0"></i>
                <p class="my-2 module-name ml-0 mr-auto"> Contracte</p>
            </div>
            <?php if($data['accessToAngajati']): ?>
            <div class="col-11 col-md-5 col-md-5-custom mx-auto module-button bg-info row text-center" onclick="goToActivities('<?php echo URLROOT; ?>', '<?php echo $data['accessToAngajati']; ?>')">
                <i class="fas fa-user-clock ml-auto mr-0"></i>
                <p class="my-2 module-name ml-0 mr-auto">Activitate</p>
            </div>
            <?php endif; ?>
            <?php if($data['accessToFacturi']): ?>
            <div class="col-11 col-md-5 col-md-5-custom mx-auto module-button bg-warning row text-center" onclick="goToFacturare('<?php echo URLROOT; ?>')">
                <i class="fas fa-file-invoice-dollar ml-auto mr-0"></i>
                <p class="my-2 module-name ml-0 mr-auto">Facturare</p>
            </div>
            <?php endif; ?>
            <?php if($data['accessToRaportare']): ?>
            <div class="col-11 col-md-5 col-md-5-custom mx-auto  module-button bg-danger row text-center">
                <i class="far fa-chart-bar ml-auto mr-0"></i>
                <p class="my-2 module-name ml-0 mr-auto">Raportare</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php else :redirect('login'); ?>
<?php endif;?>
<?php require APPROOT . '/views/inc/footer.php'; ?>
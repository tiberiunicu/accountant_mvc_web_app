<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/nav.php'; ?>


<div id="activityBody" class="col-12 row mx-0 px-0">
    <div id="addWorkLogSection" class="col-12 row mx-0 px-0">
        <div id="workLogRow" class="col-12 row mx-0 px-0 workLog-item">
            <div class="form-group col-12 col-md-3">
                <label for="clientiSelectActivity">Client :</label>
                <select id="clientiSelectActivity" class="selectpicker form-control customDropdown px-0 validate-input"
                    data-live-search="true" title="Selecteaza Client/contract"
                    onchange="setContractForLogWork('<?php echo URLROOT; ?>',this)">
                    <?php foreach ($data['contracts'] as $contract): ?>
                    <option data-contractguid="<?php echo $contract->contractGUID?>">
                        <?php echo $contract->numeClient . ' - ' .  $contract->nrContract; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group col-12 col-md-2">
                <label for="servicesForContract">Serviciu :</label>
                <select id="servicesForContract" class="selectpicker form-control customDropdown px-0 validate-input"
                    data-live-search="true" title="Selecteaza serviciul">
                    <option disabled>Selecteza clientul pentru a putea selecta serviciile</option>
                </select>
            </div>

            <div class="form-group col-12 col-md-2 date-input-desktop-worklog">
                <label for="dataLogareOreInput">Data</label>
                <input type="text" class="form-control date validate-input" data-provide="datepicker"
                    id="dataLogareOreInput" placeholder="Data">
            </div>


            <div class="form-group col-12 col-md-1">
                <label for="numarOreLucrateInput">Nr. ore :</label>
                <input type="number" min="0" max="12" class="form-control validate-input" id="numarOreLucrateInput"
                    placeholder="Nr. ore">
            </div>



            <div class="col-12 col-md-3 workLogDescription">
                <div class="form-group">
                    <label for="descriereWorkLog">Descriere</label>
                    <textarea class="form-control" id="descriereWorkLog" rows="1"></textarea>
                </div>
            </div>

            <div class="col-12 col-md-1 row ml-auto mr-0 my-auto">
                <div class=" worklogBtn btn btn-primary mt-3 mx-auto" id="addServiceButton"
                    onclick="duplicateWorkLogRow(this)">
                    <i class="fas fa-plus"></i>
                </div>
                <div class=" worklogBtn btn btn-danger mt-3 mx-auto" id="removeServiceButton"
                    onclick="removeWorkLogRow(this)">
                    <i class="fas fa-minus"></i>
                </div>
            </div>

            <!-- <div class="input-group col-4" id="servicesForContract"></div> -->

        </div>
    </div>
</div>
</div>
<script type="text/javascript">
$(document).ready(function() {
    $('.date').datepicker({
        format: 'yyyy-mm-dd',
        startDate: 'today',
        daysOfWeekDisabled: [0, 6],
        weekStart: '1'
    });
    $('.date').datepicker("setDate", new Date());
});
</script>
<?php require APPROOT . '/views/inc/footer.php'; ?>
function goToContracts(rootPath) {
    window.location.href = rootPath + '/contracts/';
}

function goToActivities(rootPath, userType) {
    if (userType == 1) {
        window.location.href = rootPath + '/activities/';
    } else if (userType == 2) {
        window.location.href = rootPath + '/activities/admin';
    }
}

function goToAddContractsPage(rootPath) {
    window.location.href = rootPath + '/contracts/new/';
}

function exportContracts(rootPath) {
    window.location.href = rootPath + '/contracts/dowloadContracts/';
}

function goToFacturare(rootPath) {
    window.location.href = rootPath + '/facturare/';
}

function setClientForLogWork(rootPath, element) {
    var workLogRow = $(element).parents('#workLogRow');
    var selectedClientID = $(workLogRow).find('#clientiSelectActivity').find('option:selected').data('clientid');
    console.log(selectedClientID);
    $.ajax({
        url: rootPath + '/Activities/getAvailableServicesForClientIDAndEmployee',
        type: 'POST',
        data: {
            servicesForClient: selectedClientID
        },
        success: function (result) {
            var finalResult = showServicesForLogWork(result);
            workLogRow.find('#servicesForClient').html(finalResult);
            workLogRow.find('#servicesForClient').val('default');
            workLogRow.find('#servicesForClient').selectpicker('refresh');
        },
        error: function () {
            alert('A aparut o eroare la preluarea serviciilor');
        }
    });
}



function duplicateWorkLogRow(element) {
    var elementToClone = $(element).parents('#workLogRow').clone();
    elementToClone.find('#numarOreLucrateInput').val('');
    elementToClone.find('#descriereWorkLog').val('');
    elementToClone.find('.is-invalid').removeClass('is-invalid');
    elementToClone.find('.invalid-feedback').remove();
    elementToClone.find('.bs-title-option').remove();
    elementToClone.find('.date').datepicker({
        format: 'yyyy-mm-dd',
        daysOfWeekDisabled: [0, 6],
        weekStart: '1'
    });
    elementToClone.find('.date').datepicker("setDate", new Date());

    // $('#addServiceButton').remove();
    // addServiceButton.appendTo(elementToClone);
    elementToClone.appendTo($('#addWorkLogSection').find('.card-body'));
    $.each(elementToClone.find('select'), function (key, value) {
        $(this).val('default');
        $(this).selectpicker('refresh');
        $(this).parent().next('.dropdown-toggle').remove();
        $(this).parent().addClass('col-12');
    })
}


function removeWorkLogRow(element) {
    if ($('.workLog-item').length > 1) {
        $(element).parents('#workLogRow').remove();
    } else {
        alert('Trebuie sa existe minim un serviciu!')
    }
}

function showServicesForLogWork(data) {
    var finalHtml = '';
    var parsedData = $.parseJSON(data);
    if (parsedData.length > 0) {
        $.each(parsedData, function () {
            var row = '';
            row += ' <option data-serviciuSelectatID="' + this.tipServiciuID + '">';
            row += this.numeTipServiciu + '</option>';

            finalHtml += row;
        })
        finalHtml += '<option data-serviciuSelectatID="0"> Diverse </option>';
    } else {
        finalHtml = 'Nu ai acces la nici un serviciu din acest contract!'
    }

    return finalHtml;
}

function showDeleteContractModal(rootPath, idContract, numarContract, numeClient) {
    var modal = $('#deleteContract');
    var modalBody = modal.find('.modal-body');
    var acceptButton = modal.find('#acceptButton');
    modalBody.html('Esti sigur ca vrei sa stergi contractul cu numarul ' + numarContract + ' si clientul: ' + numeClient + ' ?');
    modal.modal('show');
    acceptButton.attr('onClick', "deleteContract(\'" + rootPath + '\',\'' + idContract + "\')");
}

function showViewContractModal(rootPath, contractID) {
    $('#viewContract').modal('show');
    $.ajax({
        url: rootPath + '/Contracts/show/' + contractID,
        type: 'GET',
        success: function (result) {
            $('#viewContract').find('.modal-content').html(result);
        },
        error: function () {
            alert('A aparut o eroare la preluarea contractului');
        }
    });
}

function showTodayActivity(rootPath) {
    $('#todayActivity').modal('show');
    $.ajax({
        url: rootPath + '/Activities/show',
        type: 'GET',
        success: function (result) {
            $('#todayActivity').find('.modal-content').html(result);
        },
        error: function () {
            alert('A aparut o eroare la preluarea activitiatii de astazi');
        }
    });
}

function editContract(rootPath, contractID) {
    window.location.href = rootPath + '/contracts/edit/' + contractID;
}

function deleteContract(rootPath, contractID) {
    $.ajax({
        url: rootPath + '/Contracts/deleteContract',
        type: 'POST',
        data: { deleteContractID: contractID },
        success: function (result) {
            console.log('contractul a fost sters cu succes!')
            location.reload();
        },
        error: function () {
            alert('A aparut o eroare');
        }
    });
}

function checkServiceCorrectnessByServiciuTotalInput(element) {
    var serviceItem = $(element).parents('.service-item');
    var tarifOraInput = serviceItem.find('#tarifOraInput');
    var tarifServiciuTotalInput = serviceItem.find('#tarifServiciuTotalInput');
    var numarOreInput = serviceItem.find('#numarOreInput');
    var hoursResulted = tarifServiciuTotalInput.val() / tarifOraInput.val();
    numarOreInput.val(parseFloat(hoursResulted).toFixed(1));
}


function calculateDifferenceBetweenTotalServicesAndSumOfServices() {
    var sumaLunara = parseFloat($('#sumaLunaraInput').val());
    var sumaTuturorServiciilor = 0;
    $('.service-item').each(function (key, value) {
        var thisPretEstimat = parseFloat($(this).find('#tarifServiciuTotalInput').val());
        sumaTuturorServiciilor += thisPretEstimat;
    });
    parseFloat(sumaLunara - sumaTuturorServiciilor);

    return parseFloat(sumaLunara - sumaTuturorServiciilor);
}



function showClientList() {
    $('#clientList').removeClass('hidden');
}

function hideClientList() {
    $('#clientList').removeClass('hidden').addClass('hidden');
}

function showServicesList() {
    $('#servicesList').removeClass('hidden');
}

function hideServicesList() {
    $('#servicesList').removeClass('hidden').addClass('hidden');
}

function isJson(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

function prefillClientInfo(client) {
    $('#clientNameValue').val(client.numeClient);
    $('#cuiClientInput').val(client.CUI);
    $('#cuiClientInput').attr('readonly', 'true');
    $('#numeAdministratorInput').val(client.adminNumeClient);
    $('#numeAdministratorInput').attr('readonly', 'true');
    $('#emailAdministratorInput').val(client.adminEmailClient);
    $('#emailAdministratorInput').attr('readonly', 'true');
    $('#telefonAdministratorInput').attr('readonly', 'true');
    $('#numeReprezentantInput').val(client.reprezentantNumeClient);
    $('#numeReprezentantInput').attr('readonly', 'true');
    $('#emailReprezentantInput').val(client.reprezentantEmailClient);
    $('#emailReprezentantInput').attr('readonly', 'true');
    $('#telefonReprezentantInput').attr('readonly', 'true');

    if (isJson(client.reprezentantTelClient)) {
        $('#telefonReprezentantInput').val(JSON.parse(client.reprezentantTelClient).phone);
        $('#prefixReprezentantSelect').val($.trim($('#prefixReprezentantSelect').find('option[data-countryid="' + JSON.parse(client.reprezentantTelClient).prefix + '"]').text()));
        $('#prefixReprezentantSelect').selectpicker('refresh');
    }
    if (isJson(client.adminTelClient)) {
        $('#prefixAdministratorSelect').val($.trim($('#prefixAdministratorSelect').find('option[data-countryid="' + JSON.parse(client.adminTelClient).prefix + '"]').text()));
        $('#prefixAdministratorSelect').selectpicker('refresh');
        $('#telefonAdministratorInput').val(JSON.parse(client.adminTelClient).phone);
    }
}

function setClientOnSession(client) {
    sessionStorage.setItem("selectedClientID", client.clientID);
    prefillClientInfo(client);
    hideClientList();
    clearClientSectionValidationErrors(client);
}

function clearPrefilledClientInfo() {
    if ($('#cuiClientInput').val().length > 0) {
        $('#cuiClientInput').val('');
        $('#cuiClientInput').removeAttr('readonly');
        $('#numeAdministratorInput').val('');
        $('#numeAdministratorInput').removeAttr('readonly');
        $('#emailAdministratorInput').val('');
        $('#emailAdministratorInput').removeAttr('readonly');
        $('#telefonAdministratorInput').val('');
        $('#telefonAdministratorInput').removeAttr('readonly');
        $('#prefixAdministratorSelect').val('default');
        $('#prefixAdministratorSelect').selectpicker('refresh');
        $('#numeReprezentantInput').val('');
        $('#numeReprezentantInput').removeAttr('readonly');
        $('#emailReprezentantInput').val('');
        $('#emailReprezentantInput').removeAttr('readonly');
        $('#telefonReprezentantInput').val('');
        $('#telefonReprezentantInput').removeAttr('readonly');
        $('#prefixReprezentantSelect').val('default');
        $('#prefixReprezentantSelect').selectpicker('refresh');

        sessionStorage.removeItem("selectedClientID");
    }
}

function searchClientByName(element) {
    $(element).removeClass('is-invalid');
    $(element).siblings('.invalid-feedback').remove();

    var elementValue = $(element).val();
    if (event.keyCode != 9 && elementValue.length > 3) {
        showClientList();
    }

    var searchList = $('.client-list-element');
    if (elementValue.length > 3) {
        $.each(searchList, function (key, value) {
            $(this).removeClass('hidden').addClass('hidden');
            if ($(value).text().trim().toLowerCase().startsWith(elementValue.toLowerCase())) {
                $(this).removeClass('hidden');
            } else {
                clearClientSectionValidationErrors();
                clearPrefilledClientInfo();
            }
        });
    }
    if (elementValue === '') {
        hideClientList();
    }

}

function setThisFirmaPrestatoare(rootPath, element) {
    var parent = $(element).parents('.service-item');
    var firmaPrestatoareID = $(element).find('option:selected').data('firmaprestatoareid');
    parent.find('#firmaPrestatoareHiddenId').text(firmaPrestatoareID);

    //set the proposed contract number by company id

    $.ajax({
        url: rootPath + '/Contracts/getMaxContractNumber/',
        type: 'POST',
        data: {
            firmaPrestatoareID: firmaPrestatoareID
        },
        success: function (result) {
            console.log(result);
            $('#numarContractInput').val(result);
        },
        error: function () {
            alert('A aparut o eroare la propunerea numarul de contract.');
        }
    });

}

function validateUniqueCUI(element) {
    //$(element).removeClass('invalidInput');
    $(element).removeClass('is-invalid');
    $(element).parents('.form-group').find('.invalid-feedback').remove();
    // $('#invalidCUIMessage').removeClass('hidden').addClass('hidden');
    var elementValue = $(element).val();
    console.log(elementValue);
    if (validateCUI(elementValue)) {
        elementValue = elementValue.replace(/\D/g, '');
        var searchList = $('.initialClientCUI');
        $.each(searchList, function (key, value) {
            if (elementValue === $(this).text()) {
                // $(element).removeClass('invalidInput').addClass('invalidInput');
                // $('#invalidCUIMessage').text('Acest CUI exista in baza de date.')
                // $('#invalidCUIMessage').removeClass('hidden');
                if (!$(element).attr("readonly")) {
                    $(element).removeClass('is-invalid').addClass('is-invalid');
                    $(element).after('<div class="invalid-feedback">Acest CUI exista in baza de date.</div>');
                }
            }
        })
    } else {
        // $(element).removeClass('invalidInput').addClass('invalidInput');
        // $('#invalidCUIMessage').text('Cui-ul este invalid! Nu respecta formatul standard.').removeClass('hidden');
        $(element).removeClass('is-invalid').addClass('is-invalid');
        $(element).after('<div class="invalid-feedback">Cui-ul este invalid! Nu respecta formatul standard.</div>');
        return false;
    }
    // if (elementValue === ''){
    //     $(element).removeClass('invalidInput');
    //     $('#invalidCUIMessage').removeClass('hidden').addClass('hidden');
    // }
    return true;
}

function clearClientSectionValidationErrors() {
    // $('#invalidCUIMessage').removeClass('hidden').addClass('hidden');
    $('#client').find('.is-invalid').removeClass('is-invalid');
}

function duplicateServiceItem(element) {

    //var addServiceButton = $('#addServiceButton');
    var elementToClone = $(element).parents('.contract-section2').find('.service-item').first().clone();
    elementToClone.find('.is-invalid').removeClass('is-invalid');
    elementToClone.find('.invalid-feedback').remove();
    elementToClone.find('.serviceSelectParent').removeClass('col-6').addClass('col-12');
    elementToClone.find('.bs-title-option').remove();
    var servicesArray = [];
    $('.serviceCounter').each(function (key, value) { servicesArray.push($(this).text()) });
    var counterActualMaxValue = Math.max.apply(Math, servicesArray);
    var counter = counterActualMaxValue + 1;
    elementToClone.find('.serviceCounter').text(counter);
    // elementToClone.find('#serviceSelect').attr('id','serviceSelect' + counter);
    // elementToClone.find('#angajatiSelect').attr('id','angajatiSelect' + counter);
    // elementToClone.find('#firmaPrestatoareSelect').attr('id','firmaPrestatoareSelect' + counter);
    // elementToClone.find('#numarOreInput').attr('id','numarOreInput' + counter).val('');
    // elementToClone.find('#tarifOraInput').attr('id','tarifOraInput' + counter).val('');
    elementToClone.find('#newServiceName').removeClass('hidden').addClass('hidden');
    elementToClone.find('#newServiceNameInput').val('');
    var serviceEstimated = calculateDifferenceBetweenTotalServicesAndSumOfServices();
    elementToClone.find('#tarifServiciuTotalInput').val(serviceEstimated >= 0 ? serviceEstimated : 0);
    elementToClone.find('#numarOreInput').val('');
    elementToClone.find('#tarifOraInput').val('60');
    // $('#addServiceButton').remove();
    // addServiceButton.appendTo(elementToClone);
    elementToClone.appendTo($('.contract-section2'));
    $.each(elementToClone.find('select'), function (key, value) {
        $(this).val('default');
        $(this).selectpicker('refresh');
        $(this).parent().next('.dropdown-toggle').remove();
        $(this).parent().addClass('col-12');
    })
    var elmnt = document.getElementById("contract-section2");
    checkServiceCorrectnessByServiciuTotalInput(elementToClone.find('#tarifServiciuTotalInput'));
    elmnt.scrollIntoView({ behavior: "smooth", block: "end", inline: "nearest" });
    console.log('diferenta intre suma totala si suma tuturor serviciilor = ' + serviceEstimated);
}


function deleteService(element) {
    var addServiceButton = $('#addServiceButton');
    var serviceToDelete = $(element).parents('.service-item');
    if ($('.service-item').length > 1) {
        serviceToDelete.remove();
        // $('#addServiceButton').remove();
        // addServiceButton.appendTo($('.service-item').last());
    } else {
        alert('Nu se poate sterge acest serviciu! Un contract trebuie sa contina cel putin un serviciu!');
    }

}

function validateCUI(cuiValue) {
    var regex = /(^[a-zA-Z]{2})??\d{2,10}$/y;
    var res = regex.test(cuiValue);
    return res;
}

function validateField(element) {
    var formGroup = $(element).parents('.form-group');
    var elementByParent = formGroup.children('.validate-input');
    var elementval = $(element).val();

    formGroup.find('.invalid-feedback').remove();

    if ((elementval == '' || elementval == undefined)) {
        elementByParent.removeClass('is-invalid').addClass('is-invalid');
        let errorHtml = '<div class="invalid-feedback">Campul este obligatoriu.</div>';
        elementByParent.after(errorHtml);

    } else if ($(element).is('#cuiClientInput')) {

        validateUniqueCUI(element);

    } else {
        elementByParent.removeClass('is-invalid');
    }
}

function validateContract() {
    var form = $("input.validate-input, select.validate-input");

    form.each(function (key, element) {
        validateField(element);
    });

    var invalidField = $('.is-invalid').length;

    if (calculateDifferenceBetweenTotalServicesAndSumOfServices() != 0) {
        alert("Suma tuturor serviciilor este diferita de suma lunara stabilita!");
        return false;
    }

    if (invalidField > 0) {
        return false;
    } else {
        return true;
    }
}

function updateContract(rootPath, contractID) {

    if (!validateContract()) {
        return;
    }

    var modal = $('#updateContractModal');
    modal.modal('show');

    $.when(deleteServicesByContract(rootPath, contractID)).then(() => updateContractIntoDatabase(rootPath, contractID)).then(() => updateServicesIntoDatabase(rootPath, contractID));

}

function deleteServicesByContract(rootPath, contractID) {

    return $.ajax({
        url: rootPath + '/Contracts/deleteServicesByContract/',
        type: 'POST',
        data: {
            contractID: contractID,
        },
        success: function (result) {
            console.log('serviciile contractului au fost sterse');
        },
        error: function () {
            alert('A aparut o eroare la stergerea serviciilor contractului');
        }
    });

}

function updateContractIntoDatabase(rootPath, contractID) {
    var contractNumber = $('#numarContractInput').val();
    var sumaLunara = $('#sumaLunaraInput').val();
    var tipFacturareID = $('#facturareSelect').find('option:selected').data('facturareid');
    var dataIncepereContract = $('#dataIncepereContractInput').val();
    var dataFinalizareContract = $('#dataFinalizareContractInput').val();
    var numeClient = $('#clientNameValue').val();
    var cuiClient = $('#cuiClientInput').val();
    var numeAdministrator = $('#numeAdministratorInput').val();
    var emailAdministrator = $('#emailAdministratorInput').val();
    var telAdministrator = JSON.stringify({ prefix: $('#prefixAdministratorSelect').find('option:selected').data('countryid'), phone: $('#telefonAdministratorInput').val() });
    var numeReprezentant = ($('#numeReprezentantInput').val() != '') ? $('#numeReprezentantInput').val() : ' ';
    var emailReprezentant = ($('#emailReprezentantInput').val() != '') ? $('#emailReprezentantInput').val() : ' ';
    var telReprezentant = JSON.stringify({ prefix: $('#prefixAdministratorSelect').find('option:selected').data('countryid'), phone: $('#telefonAdministratorInput').val() });
    var firmaPrestatoareID = $('#firmaPrestatoareSelect').find('option:selected').data('firmaprestatoareid');


    return $.ajax({
        url: rootPath + '/Contracts/UpdateContract/' + contractID,
        type: 'POST',
        data: {
            contractNumber: contractNumber,
            sumaLunara: sumaLunara,
            tipFacturareID: tipFacturareID,
            dataIncepereContract: dataIncepereContract,
            dataFinalizareContract: dataFinalizareContract,
            numeClient: numeClient,
            cuiClient: cuiClient,
            numeAdministrator: numeAdministrator,
            emailAdministrator: emailAdministrator,
            telAdministrator: telAdministrator,
            numeReprezentant: numeReprezentant,
            emailReprezentant: emailReprezentant,
            telReprezentant: telReprezentant,
            firmaPrestatoareID: firmaPrestatoareID
        },
        success: function (result) {
            console.log('contractul a fost modificat cu success');
        },
        error: function () {
            alert('A aparut o eroare la modificarea contractului');
        }
    });

}

function updateServicesIntoDatabase(rootPath, contractID) {
    var serviceItems = [];
    $('.service-item').each(function (key, value) {
        var serviceItem = {};
        var serviciuID = $(this).find('#serviceSelect').find('option:selected').data('serviceid');
        if (serviciuID.trim() == '7') {
            var newServiceName = $(this).find('#newServiceNameInput').val();
        }
        var angajatIDs = getAngajatForService(this);
        var numarOreEstimate = $(this).find('#numarOreInput').val();
        var tarifServiciuTotal = $(this).find('#tarifServiciuTotalInput').val();
        var pretOra = $(this).find('#tarifOraInput').val();

        serviceItem = {
            "serviciuID": serviciuID,
            "angajatIDs": angajatIDs,
            "numarOreEstimate": numarOreEstimate,
            "tarifServiciuTotal": tarifServiciuTotal,
            "pretOra": pretOra
        };

        serviceItems.push(serviceItem);

    });

    return $.ajax({
        url: rootPath + '/Contracts/updateServiceInContractServiciuTable/' + contractID,
        type: 'POST',
        data: {
            servicesList: JSON.stringify(serviceItems)
        },
        success: function (result) {
            console.log('seriviciile au fost modificate cu success');
            goToContracts(rootPath);
        },
        error: function () {
            console.log('A aparut o eroare la modificarea serviciilor in baza de date');
            $('#updateContractModal').find('.modal-body').html("A aparut o problema la modificarea serviciilor. Te rugam sa reincerci! Poti da refresh sau astepti 10 secunde..");
            setTimeout(function () {
                location.reload();
            }, 10000);
        }
    });
}

function saveContract(rootPath) {

    if (!validateContract()) {
        return;
    }
    var modal = $('#saveContractModal');
    modal.modal('show');
    // insertServicesIntoDatabase(rootPath).done(()=>insertContrantIntoDatabase(rootPath));
    $.when(insertServicesIntoDatabase(rootPath)).then(() => insertContrantIntoDatabase(rootPath));
}

function insertContrantIntoDatabase(rootPath) {
    var contractNumber = $('#numarContractInput').val();
    var sumaLunara = $('#sumaLunaraInput').val();
    var tipFacturareID = $('#facturareSelect').find('option:selected').data('facturareid');
    var dataIncepereContract = $('#dataIncepereContractInput').val();
    var dataFinalizareContract = $('#dataFinalizareContractInput').val();
    var firmaPrestatoareID = $('#firmaPrestatoareSelect').find('option:selected').data('firmaprestatoareid');
    var tipMonedaID = $('#monedaSelect').find('option:selected').data('monedaid');
    var clientID = '';
    if (sessionStorage.getItem("selectedClientID") != undefined) {
        clientID = sessionStorage.getItem("selectedClientID");
    } else {
        clientID = '0';
        var numeClient = $('#clientNameValue').val();
        var cuiClient = $('#cuiClientInput').val();
        var numeAdministrator = $('#numeAdministratorInput').val();
        var emailAdministrator = $('#emailAdministratorInput').val();
        var telAdministrator = JSON.stringify({ prefix: $('#prefixAdministratorSelect').find('option:selected').data('countryid'), phone: $('#telefonAdministratorInput').val() });
        var numeReprezentant = ($('#numeReprezentantInput').val() != '') ? $('#numeReprezentantInput').val() : ' ';
        var emailReprezentant = ($('#emailReprezentantInput').val() != '') ? $('#emailReprezentantInput').val() : ' ';
        var telReprezentant = JSON.stringify({ prefix: $('#prefixAdministratorSelect').find('option:selected').data('countryid'), phone: $('#telefonAdministratorInput').val() });
    }
    $.ajax({
        url: rootPath + '/Contracts/SaveContract',
        type: 'POST',
        data: {
            contractNumber: contractNumber,
            sumaLunara: sumaLunara,
            tipFacturareID: tipFacturareID,
            dataIncepereContract: dataIncepereContract,
            dataFinalizareContract: dataFinalizareContract,
            clientID: clientID,
            numeClient: numeClient,
            cuiClient: cuiClient,
            numeAdministrator: numeAdministrator,
            emailAdministrator: emailAdministrator,
            telAdministrator: telAdministrator,
            numeReprezentant: numeReprezentant,
            emailReprezentant: emailReprezentant,
            telReprezentant: telReprezentant,
            firmaPrestatoareID: firmaPrestatoareID,
            tipMonedaID: tipMonedaID
        },
        success: function (result) {
            console.log('contractul a fost salvat cu success');
            goToContracts(rootPath);
        },
        error: function () {
            alert('A aparut o eroare la salvarea contractului');
        }
    });
}


function insertServicesIntoDatabase(rootPath) {
    $('.service-item').each(function (key, value) {
        var serviciuID = $(this).find('#serviceSelect').find('option:selected').data('serviceid');
        if (serviciuID.trim() == '7') {
            var newServiceName = $(this).find('#newServiceNameInput').val();
        }
        var angajatIDs = getAngajatForService(this);
        var tarifServiciuTotal = $(this).find('#tarifServiciuTotalInput').val();
        var numarOreEstimate = $(this).find('#numarOreInput').val();
        var pretOra = $(this).find('#tarifOraInput').val();

        $.ajax({
            url: rootPath + '/Contracts/insertServiceInContractServiciuTable',
            type: 'POST',
            data: {
                serviciuID: serviciuID,
                newServiceName: newServiceName,
                angajatIDs: angajatIDs,
                tarifServiciuTotal: tarifServiciuTotal,
                numarOreEstimate: numarOreEstimate,
                pretOra: pretOra
            },
            success: function (result) {
                console.log('seriviciile au fost adaugate cu success');
            },
            error: function () {
                console.log('A aparut o eroare la inserarea serviciilor in baza de date');
                $('#saveContractModal').find('.modal-body').html("A aparut o problema la inserarea serviciilor. Te rugam sa reincerci! Poti da refresh sau astepti 10 secunde..");
                setTimeout(function () {
                    location.reload();
                }, 10000);
            }
        });
    });
}

function setAngajatForThisService(element) {
    var parent = $(element).parents('.service-item');
    var selected = $(element).find('option:selected');
    var selectedList = [];
    $(selected).each(function (index, brand) {
        selectedList.push($(this).data('angajatid'));
    });
    parent.find('#angajatiHiddenIds').text(selectedList);

}

function getAngajatForService(element) {
    var selected = $(element).find('#angajatiSelect').find('option:selected');
    var selectedList = [];
    $(selected).each(function (index, brand) {
        selectedList.push($(this).data('angajatid'));
    });
    return selectedList.toString();
}

function setThisService(element) {
    var parent = $(element).parents('.service-item');
    var serviceID = $(element).find('option:selected').data('serviceid');
    parent.find('#serviceHiddenId').text(serviceID);
    if (serviceID.trim() == '7') {
        parent.find('.serviceSelectParent').removeClass('col-12').addClass('col-6');
        parent.find('#newServiceName').removeClass('hidden');
        parent.find('#newServiceNameInput').removeClass('validate-input').addClass('validate-input');
        delegateNewService();
    } else {
        parent.find('.serviceSelectParent').removeClass('col-6').addClass('col-12');
        parent.find('#newServiceName').removeClass('hidden').addClass('hidden');
        parent.find('#newServiceNameInput').removeClass('validate-input').removeClass('is-invalid');
    }
}

function delegateNewService() {
    $('#newServiceNameInput').on('blur', function () {
        validateField(this);
    });
}

function clearPHPContractGUID(rootPath) {
    $.ajax({
        url: rootPath + '/Contracts/DeletePreviousContractGUID',
        type: 'POST',
        data: {
            deletePreviousContractGUIDPHP: true
        },
        success: function (result) {
            console.log(result);
        },
        error: function () {
            alert('A aparut o eroare la stergerea GUID-ului anterior');
        }
    });
}


/* Set the width of the sidebar to 250px and the left margin of the page content to 250px */
function openNav() {
    document.getElementById("mySidebar").style.width = "18.0%";
    // document.getElementById("contractListBody").style.marginLeft = "280px";
    $('#contractListBody').removeClass('col-12').addClass('col-10');
}

/* Set the width of the sidebar to 0 and the left margin of the page content to 0 */
function closeNav() {
    document.getElementById("mySidebar").style.width = "10px";
    document.getElementById("contractListBody").style.marginLeft = "0px";
    setTimeout(function () {
        $('#contractListBody').removeClass('col-10').addClass('col-12');
    }, 250);
}


function resetFilters() {
    location.reload();
}

function applyFilters(rootPath) {
    $('.table-striped').removeClass('loading').addClass('loading');
    var numeClientSearch = $('#numeClientSearchInput').val();
    var numeAdministrator = $('#numeAdministratorSearchInput').val();
    var cuiSearch = $('#cuiSearchInput').val();
    var firmaPrestatoareFilter = $('#firmaPrestatoareSearchSelect').find('option:selected').data('firmaprestatoareid');
    $.ajax({
        url: rootPath + '/Contracts/ApplyFilters',
        type: 'POST',
        data: {
            numeClientFilter: numeClientSearch,
            numeAdministratorFilter: numeAdministrator,
            cuiFilter: cuiSearch,
            firmaPrestatoareFilter: firmaPrestatoareFilter,
        },
        success: function (result) {
            var finalResult = recreateContractsList(result);
            $('#contractsListTable').html(finalResult);
            setTimeout(function () {
                $('.table-striped').removeClass('loading')
            }, 1000);
        },
        error: function () {
            alert('A aparut o eroare la salvarea contractului');
        }
    });
}

function validateEmailAddress(element) {
    $(element).removeClass('is-invalid');
    $(element).parents('.form-group').find('.invalid-feedback').remove();
    var value = $(element).val();
    if (value != '') {
        var emailValidRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        var validationResult = emailValidRegex.test(value.toLowerCase());
        if (validationResult === false) {
            $(element).removeClass('is-invalid').addClass('is-invalid');
            $(element).after('<div class="invalid-feedback">Aceasta nu este o adresa de email valida.</div>');
        }
    }
}

function validatePhoneNumberMaxLength(element) {
    setTimeout(() => {
        $(element).parents('.form-group').find('.warning-feedback').remove();
    }, 2000);

    var value = $(element).val();
    if (value.length > 10) {
        $(element).val(value.substr(0, 10));
        $(element).after('<div class="warning-feedback text-warning text-right">Lungimea maxima pentru acest camp este de 10 caractere.</div>');
    }
}

function recreateContractsList(filteredData) {
    var userHasAccessToContracts = $('#hiddenFieldUserAccessToContracts').data('hasaccesstocontracts');
    var URLROOT = $('#hiddenURLROOT').data('urlroot');

    var finalHtml = '';
    var parsedFilteredData = $.parseJSON(filteredData);
    if (parsedFilteredData.length > 0) {
        $.each(parsedFilteredData, function () {
            var tableRow = '';
            tableRow += '<tr data-contractID="' + this.contractID + '"> '
                + '<td scope="row">' + this.nrContract + '</th>'
                + '<td class="left">' + this.numeClient + '</td>'
                + '<td class="left">' + this.adminNumeClient + '</td>'
                + '<td class="left">' + this.reprezentantNumeClient + '</td>'
                + '<td class="left servicii-value">' + this.servicii + '</td>'
                + '<td class="center action-buttons">'
                + '    <span class="text-info" '
                + '        title="Vizualizare contract" '
                + '        onclick="showViewContractModal(\'' + URLROOT + '\',\'' + this.contractID + '\')">'
                + '        <i class="fas fa-eye fa-lg"></i></span>';
            if (userHasAccessToContracts) {
                tableRow +=
                    '<span class="text-primary" title="Modifica contract" '
                    + ' onclick="editContract(\'' + URLROOT + '\',\'' + this.contractID + '\')">'
                    + '            <i class="fas fa-edit fa-lg"></i></span>'
                    + '    <span class="text-danger" title="Sterge contract"'
                    + '        onclick="showDeleteContractModal(\'' + URLROOT + '\',\'' + this.contractID + '\',\'' + this.nrContract + '\',\' ' + this.numeClient + '\')">'
                    + '        <i class="fas fa-trash-alt fa-lg"></i></span>'
                    + '        </td>';
            }
            tableRow += '    </tr>';

            finalHtml += tableRow;
        })
    } else {
        finalHtml = '<p class="text-center">Nu au fost gasite contracte care sa se potriveasca filtrelor.</p>';
    }
    return finalHtml;
}
//    Salvare Activitate Start
function saveActivity(rootPath, angajatID) {

    if (!validateActivity()
    ) {
        return
    }

    $('.card-footer').find('.spinner-border').removeClass('hidden');
    $('#addActivityBtn').attr('disabled', 'disabled');
    $('.workLog-item').each(function (key, value) {

        var clientID = $(this).find('#clientiSelectActivity').find('option:selected').data('clientid');
        var tipServiciuID = $(this).find('#servicesForClient').find('option:selected').data('serviciuselectatid');
        var logDate = $(this).find('#dataLogareOreInput').val();
        var nrOre = $(this).find('#numarOreLucrateInput').val();
        var descriere = $(this).find('#descriereWorkLog').val();

        $.ajax({
            url: rootPath + '/Activities/saveActivity',
            type: 'POST',
            data: {
                angajatID: angajatID,
                clientID: clientID,
                tipServiciuID: tipServiciuID,
                logDate: logDate,
                nrOre: nrOre,
                descriere: descriere
            },
            success: function (result) {
                console.log('activitatea a fost iregistrata cu success');
                goToActivities(rootPath, 1);
                // $('.card-footer').find('.spinner-border').removeClass('hidden').addClass('hidden');
                // $('#addActivityBtn').removeAttr('disabled');
            },
            error: function () {
                console.log('A aparut o eroare la inregistrarea activitatii in baza de date');
            }
        });
    });

}

function validateActivity() {
    var form = $("input.validate-input, select.validate-input");

    form.each(function (key, element) {
        validateField(element);
    });

    var invalidField = $('.is-invalid').length;

    if (invalidField > 0) {
        return false;
    } else {
        return true;
    }

}
//    Salvare Activitate End

//to use later DO NOT DELETE

// $(element).find('option:selected').data('serviceid')

// $(function() {
//     $("#angajatiSelect").on("changed.bs.select", function(e, clickedIndex, newValue, oldValue) {
//         var optionClicked = $(this).find('option').eq(clickedIndex);
//         var brands = $('#angajatiSelect option:selected');
//         var selected = [];
//         $(brands).each(function(index, brand) {
//             selected.push($(this).data('angajatid'));
//         });
//         setAngajatForThisService(optionClicked, selected);
//     });
//     $("#serviceSelect").on("changed.bs.select", function(e, clickedIndex, newValue, oldValue) {
//         var selectedID = $(this).find('option').eq(clickedIndex).data('serviceid');
//         var optionClicked = $(this).find('option').eq(clickedIndex);
//         setThisService(optionClicked, selectedID);
//     });

//     $("#firmaPrestatoareSelect").on("changed.bs.select", function(e, clickedIndex, newValue, oldValue) {
//         var selectedID = $(this).find('option').eq(clickedIndex).data('firmaprestatoareid');
//         var optionClicked = $(this).find('option').eq(clickedIndex);
//         setThisFirmaPrestatoare(optionClicked, selectedID);
//     });

// });

function suggestedDate() {
    var today = new Date();
    // var today = new Date('2020-06-15');
    var day = today.getDay();
    var suggestedDay;

    switch (day) {
        case 6:
            suggestedDay = new Date().setDate(today.getDate() - 1);
            break;
        case 0:
            suggestedDay = new Date().setDate(today.getDate() - 2);
            break;
        default:
            suggestedDay = new Date().setDate(today.getDate());
    }

    return new Date(suggestedDay);
}

function startDate() {
    var today = new Date();

    //var today = new Date('2020-06-15');
    var day = today.getDay();
    var prevMonday;
    switch (day) {
        case 1:
            prevMonday = new Date().setDate(today.getDate() - 7);
            break;
        case 0:
            prevMonday = new Date().setDate(today.getDate() - 6);
            break;
        default:
            prevMonday = new Date().setDate(today.getDate() - day + 1);
    }

    return new Date(prevMonday);
}


function uploadDocuments(rootPath) {
    alert(rootPath);
}

function contracteCareExpira() {
    $('.contract-item').hide();
    $('.expiring').show();
    $('#afiseazaToate').removeClass('hidden');
    $('#contracteCareExpira').hide();

}

function afiseazaToate() {
    $('.contract-item').hide();
    $('.expiring').hide();
    $('#afiseazaToate').removeClass('hidden').addClass('hidden');
    $('.contract-item').show();
    $('#contracteCareExpira').show();
}

function cautareUniversala(element) {
    var searchedValue = $(element).val();
    if (searchedValue != '') {
        $('.contract-item').hide();
        $('.contract-item > td.left:contains("' + searchedValue + '")').parents(".contract-item").show()
    } else {
        $('.contract-item').hide();
        $('.contract-item').show();
    }
    // alert(searchedValue);

}

// !!!!rewrite jquery contains function!!!!
jQuery.expr[':'].contains = function (a, i, m) {
    return jQuery(a).text().toUpperCase()
        .indexOf(m[3].toUpperCase()) >= 0;
};
// !!!!rewrite jquery contains function!!!!